import { SampleUrl } from '../types';

export const SAMPLE_URLS: SampleUrl[] = [
  {
    name: 'Big Buck Bunny (MP4 Video)',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    category: 'Video (MP4)',
    estimatedSize: '158.0 MB',
  },
  {
    name: 'Elephants Dream (MKV Video)',
    url: 'https://archive.org/download/ElephantsDream/ed_1024_512kb.mp4',
    category: 'Video (MKV)',
    estimatedSize: '42.6 MB',
  },
  {
    name: 'Sample Documentation (PDF)',
    url: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    category: 'Document (PDF)',
    estimatedSize: '13.2 KB',
  },
  {
    name: 'Sample Release Archive (ZIP)',
    url: 'https://github.com/torvalds/linux/archive/refs/tags/v6.8.zip',
    category: 'Archive (ZIP)',
    estimatedSize: '245.8 MB',
  },
  {
    name: 'Android Open Source (APK)',
    url: 'https://github.com/termux/termux-app/releases/download/v0.118.0/termux-app_v0.118.0+github-debug_arm64-v8a.apk',
    category: 'Android Package (APK)',
    estimatedSize: '97.4 MB',
  },
  {
    name: 'High-Res Wallpaper (WEBP)',
    url: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?q=80&w=2094&auto=format&fit=crop',
    category: 'Image (WEBP)',
    estimatedSize: '3.4 MB',
  },
];
