export interface CodeFile {
  path: string;
  name: string;
  language: string;
  description: string;
  content: string;
}

export const ANDROID_CODE_FILES: CodeFile[] = [
  {
    path: 'app/src/main/java/com/drivedrop/app/data/network/CloudApiService.kt',
    name: 'CloudApiService.kt',
    language: 'kotlin',
    description: 'Android Network Client: Submits direct URLs to Cloud Backend & polls real-time transfer status (0 phone data used).',
    content: `package com.drivedrop.app.data.network

import com.drivedrop.app.data.model.CloudJobStatusResponse
import com.drivedrop.app.data.model.UploadRequest
import com.drivedrop.app.data.model.UploadResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class CloudApiService(private val backendBaseUrl: String = "https://drivedrop-backend-run.app") {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private val jsonMedia = "application/json; charset=utf-8".toMediaType()

    /**
     * POST /api/upload
     * Sends the direct URL to the cloud backend. Phone NEVER downloads the file.
     */
    suspend fun submitUploadJob(
        directUrl: String,
        folderName: String = "DriveDrop",
        customFileName: String? = null,
        authToken: String? = null
    ): UploadResponse = withContext(Dispatchers.IO) {
        val jsonPayload = JSONObject().apply {
            put("url", directUrl)
            put("folderName", folderName)
            if (!customFileName.isNullOrBlank()) {
                put("customFileName", customFileName)
            }
        }

        val requestBuilder = Request.Builder()
            .url("$backendBaseUrl/api/upload")
            .post(jsonPayload.toString().toRequestBody(jsonMedia))

        authToken?.let {
            requestBuilder.header("Authorization", "Bearer $it")
        }

        val response = client.newCall(requestBuilder.build()).execute()
        val bodyString = response.body?.string() ?: throw IOException("Empty response from backend")

        if (!response.isSuccessful) {
            val errObj = try { JSONObject(bodyString) } catch (_: Exception) { JSONObject() }
            val msg = errObj.optString("message", "HTTP \${response.code} error from cloud backend")
            throw IOException(msg)
        }

        val json = JSONObject(bodyString)
        UploadResponse(
            jobId = json.getString("jobId"),
            status = json.getString("status"),
            fileName = json.optString("fileName", "file"),
            message = json.optString("message", "Job queued on cloud"),
            createdAt = json.optLong("createdAt", System.currentTimeMillis())
        )
    }

    /**
     * GET /api/upload/{jobId}/status
     * Retrieves cloud transfer progress (downloading from source vs uploading to Drive).
     */
    suspend fun getJobStatus(jobId: String, authToken: String? = null): CloudJobStatusResponse = withContext(Dispatchers.IO) {
        val requestBuilder = Request.Builder()
            .url("$backendBaseUrl/api/upload/$jobId/status")
            .get()

        authToken?.let {
            requestBuilder.header("Authorization", "Bearer $it")
        }

        val response = client.newCall(requestBuilder.build()).execute()
        val bodyString = response.body?.string() ?: throw IOException("Empty response from backend")

        if (!response.isSuccessful) {
            throw IOException("HTTP \${response.code}: Failed to query job status")
        }

        val json = JSONObject(bodyString)
        CloudJobStatusResponse(
            jobId = json.getString("jobId"),
            status = json.getString("status"),
            progress = json.optInt("progress", 0),
            downloadProgress = json.optInt("downloadProgress", 0),
            uploadProgress = json.optInt("uploadProgress", 0),
            downloadSpeedMBs = json.optDouble("downloadSpeedMBs", 0.0),
            uploadSpeedMBs = json.optDouble("uploadSpeedMBs", 0.0),
            fileName = json.optString("fileName", "unknown"),
            fileSizeBytes = json.optLong("fileSizeBytes", 0L),
            mimeType = json.optString("mimeType", "application/octet-stream"),
            message = json.optString("message", ""),
            driveFileId = json.optString("driveFileId", null),
            driveFolderPath = json.optString("driveFolderPath", "DriveDrop"),
            error = json.optString("error", null)
        )
    }

    /**
     * POST /api/upload/{jobId}/cancel
     */
    suspend fun cancelJob(jobId: String): Boolean = withContext(Dispatchers.IO) {
        val req = Request.Builder()
            .url("$backendBaseUrl/api/upload/$jobId/cancel")
            .post("{}".toRequestBody(jsonMedia))
            .build()
        val res = client.newCall(req).execute()
        res.isSuccessful
    }
}`
  },
  {
    path: 'app/src/main/java/com/drivedrop/app/work/DriveDropSyncWorker.kt',
    name: 'DriveDropSyncWorker.kt',
    language: 'kotlin',
    description: 'WorkManager Background Monitor: Polls cloud job status & posts notifications without draining mobile battery or bandwidth.',
    content: `package com.drivedrop.app.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.drivedrop.app.DriveDropApp
import com.drivedrop.app.data.model.TransferEntity
import com.drivedrop.app.data.model.TransferStatus
import com.drivedrop.app.data.network.CloudApiService
import com.drivedrop.app.utils.NotificationHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

class DriveDropSyncWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    private val app = appContext.applicationContext as DriveDropApp
    private val database = app.database
    private val notificationHelper = NotificationHelper(appContext)
    private val cloudApiService = CloudApiService()

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val transferId = inputData.getString("KEY_TRANSFER_ID") ?: return@withContext Result.failure()
        val jobId = inputData.getString("KEY_JOB_ID") ?: return@withContext Result.failure()

        var isComplete = false
        var attempts = 0

        while (!isComplete && attempts < 300) { // Max 15 minutes polling window
            attempts++
            try {
                val status = cloudApiService.getJobStatus(jobId)

                val mappedStatus = when (status.status.uppercase()) {
                    "QUEUED" -> TransferStatus.QUEUED
                    "DOWNLOADING" -> TransferStatus.DOWNLOADING
                    "UPLOADING" -> TransferStatus.UPLOADING
                    "COMPLETED" -> TransferStatus.UPLOAD_COMPLETED
                    "CANCELLED" -> TransferStatus.CANCELLED
                    else -> TransferStatus.FAILED
                }

                // Update Room Database for UI
                val existing = database.transferDao().getTransferById(transferId)
                if (existing != null) {
                    database.transferDao().updateTransfer(
                        existing.copy(
                            status = mappedStatus,
                            downloadProgress = status.downloadProgress,
                            uploadProgress = status.uploadProgress,
                            fileSizeBytes = status.fileSizeBytes,
                            fileName = status.fileName,
                            mimeType = status.mimeType,
                            driveFileId = status.driveFileId,
                            errorMessage = status.error,
                            completedAtTimestamp = if (mappedStatus == TransferStatus.UPLOAD_COMPLETED) System.currentTimeMillis() else null
                        )
                    )
                }

                // Update Foreground / Ongoing Notification
                if (mappedStatus == TransferStatus.DOWNLOADING || mappedStatus == TransferStatus.UPLOADING) {
                    notificationHelper.showProgressNotification(
                        notificationId = transferId.hashCode(),
                        fileName = status.fileName,
                        message = "Cloud: \${status.message}",
                        progress = if (mappedStatus == TransferStatus.DOWNLOADING) status.downloadProgress else status.uploadProgress
                    )
                }

                if (mappedStatus == TransferStatus.UPLOAD_COMPLETED) {
                    notificationHelper.showCompletionNotification(
                        notificationId = transferId.hashCode(),
                        fileName = status.fileName,
                        isSuccess = true
                    )
                    isComplete = true
                    return@withContext Result.success(workDataOf("driveFileId" to status.driveFileId))
                } else if (mappedStatus == TransferStatus.FAILED || mappedStatus == TransferStatus.CANCELLED) {
                    notificationHelper.showCompletionNotification(
                        notificationId = transferId.hashCode(),
                        fileName = status.fileName,
                        isSuccess = false,
                        errorMessage = status.error
                    )
                    isComplete = true
                    return@withContext Result.failure(workDataOf("error" to status.error))
                }

            } catch (e: Exception) {
                // Transient network retry
            }

            delay(1500) // Poll interval
        }

        Result.success()
    }
}`
  },
  {
    path: 'server/server.ts',
    name: 'server.ts (Cloud Run Backend)',
    language: 'typescript',
    description: 'Cloud Backend Entry Point: Express REST API & Streaming Engine deployed to Google Cloud Run.',
    content: `import express, { Request, Response } from 'express';
import { createUploadJob, getJob, getAllJobs, cancelJob } from './src/backend/cloudWorker';

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Enable CORS for Android client & Web Dashboard
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.sendStatus(200);
  next();
});

// 1. Submit Direct URL for Cloud Transfer
app.post('/api/upload', (req: Request, res: Response) => {
  const { url, folderName, customFileName } = req.body || {};
  if (!url || !url.startsWith('http')) {
    return res.status(400).json({ error: 'Valid HTTP/HTTPS direct URL is required.' });
  }

  const token = req.headers.authorization?.replace('Bearer ', '');
  const job = createUploadJob(url, {
    folderName: folderName || 'DriveDrop',
    customFileName,
    googleAccessToken: token,
  });

  return res.status(202).json({
    jobId: job.jobId,
    status: job.status.toLowerCase(),
    fileName: job.fileName,
    message: 'Job accepted. Streaming directly from source to Google Drive on cloud worker.',
    createdAt: job.createdAt,
  });
});

// 2. Poll Status (Android receives 0 MB of file data)
app.get('/api/upload/:jobId/status', (req: Request, res: Response) => {
  const job = getJob(req.params.jobId);
  if (!job) return res.status(404).json({ error: 'Job not found' });
  return res.json(job);
});

// 3. Cancel Cloud Transfer
app.post('/api/upload/:jobId/cancel', (req: Request, res: Response) => {
  const ok = cancelJob(req.params.jobId);
  return res.json({ success: ok });
});

// 4. Retrieve all recent jobs
app.get('/api/jobs', (req: Request, res: Response) => {
  return res.json({ jobs: getAllJobs() });
});

app.listen(PORT, () => {
  console.log(\`[DriveDrop] Cloud Backend running on port \${PORT}\`);
});`
  },
  {
    path: 'server/cloudWorker.ts',
    name: 'cloudWorker.ts (Streaming Pipeline)',
    language: 'typescript',
    description: 'Cloud Streaming Core: Pipes direct URL stream into Google Drive v3 Resumable Upload session without loading whole file in RAM.',
    content: `import { CloudJob } from './types';

export async function processCloudTransfer(job: CloudJob, accessToken: string) {
  // 1. Open HTTP Stream from Direct URL
  const response = await fetch(job.url, {
    headers: { 'User-Agent': 'DriveDrop-Cloud-Worker/2.0 (Google-Cloud-Run)' },
  });

  if (!response.ok) {
    throw new Error(\`Download failed: Source server returned HTTP \${response.status}\`);
  }

  const contentLength = parseInt(response.headers.get('content-length') || '0', 10);
  job.fileSizeBytes = contentLength;
  job.status = 'DOWNLOADING';

  // 2. Locate or Create "DriveDrop" Folder in Google Drive
  const folderId = await getOrCreateDriveFolder(job.driveFolderPath, accessToken);

  // 3. Initiate Google Drive Resumable Upload Session
  const initRes = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable', {
    method: 'POST',
    headers: {
      Authorization: \`Bearer \${accessToken}\`,
      'Content-Type': 'application/json',
      'X-Upload-Content-Type': job.mimeType,
      'X-Upload-Content-Length': String(contentLength),
    },
    body: JSON.stringify({ name: job.fileName, parents: folderId ? [folderId] : [] }),
  });

  const uploadSessionUrl = initRes.headers.get('location')!;

  // 4. Stream Source Chunks into Google Drive Resumable Session (Memory Efficient)
  const reader = response.body!.getReader();
  let uploadedBytes = 0;

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    // Send chunk to Google Drive Resumable Upload
    await fetch(uploadSessionUrl, {
      method: 'PUT',
      headers: {
        'Content-Range': \`bytes \${uploadedBytes}-\${uploadedBytes + value.length - 1}/\${contentLength}\`,
      },
      body: value,
    });

    uploadedBytes += value.length;
    job.uploadProgress = Math.round((uploadedBytes / contentLength) * 100);
  }

  job.status = 'COMPLETED';
}`
  },
  {
    path: 'app/src/main/java/com/drivedrop/app/ui/viewmodel/MainViewModel.kt',
    name: 'MainViewModel.kt',
    language: 'kotlin',
    description: 'Android ViewModel: Initiates cloud job via API and delegates background monitoring to WorkManager.',
    content: `package com.drivedrop.app.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.drivedrop.app.DriveDropApp
import com.drivedrop.app.data.model.TransferEntity
import com.drivedrop.app.data.model.TransferStatus
import com.drivedrop.app.data.network.CloudApiService
import com.drivedrop.app.utils.UrlValidator
import com.drivedrop.app.work.DriveDropSyncWorker
import kotlinx.coroutines.launch
import java.util.UUID

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val app = getApplication<DriveDropApp>()
    private val database = app.database
    private val securePreferences = app.securePreferences
    private val cloudApiService = CloudApiService()

    fun startTransfer(onRequireAuth: () -> Unit) {
        val url = urlInput.value.trim()
        if (!UrlValidator.isValidDirectUrl(url)) {
            _urlError.value = "Please enter a valid HTTP or HTTPS direct download URL"
            return
        }

        viewModelScope.launch {
            _isStarting.value = true
            try {
                // 1. Submit direct URL to Cloud Backend
                val response = cloudApiService.submitUploadJob(
                    directUrl = url,
                    folderName = securePreferences.getDefaultFolderName()
                )

                val localId = UUID.randomUUID().toString()
                val entity = TransferEntity(
                    id = localId,
                    directUrl = url,
                    fileName = response.fileName,
                    status = TransferStatus.QUEUED,
                    downloadProgress = 0,
                    uploadProgress = 0
                )
                database.transferDao().insertTransfer(entity)

                // 2. Schedule lightweight sync worker for background monitoring
                val syncRequest = OneTimeWorkRequestBuilder<DriveDropSyncWorker>()
                    .setInputData(workDataOf("KEY_TRANSFER_ID" to localId, "KEY_JOB_ID" to response.jobId))
                    .build()
                WorkManager.getInstance(getApplication()).enqueue(syncRequest)

                _urlInput.value = ""
            } catch (e: Exception) {
                _urlError.value = "Cloud transfer failed: \${e.message}"
            } finally {
                _isStarting.value = false
            }
        }
    }
}`
  },
  {
    path: 'Dockerfile',
    name: 'Dockerfile (Cloud Run Deployment)',
    language: 'dockerfile',
    description: 'Production container configuration for Google Cloud Run.',
    content: `FROM node:20-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM node:20-alpine AS runner
WORKDIR /app
ENV NODE_ENV=production
ENV PORT=3000
COPY package*.json ./
RUN npm ci --only=production
COPY --from=builder /app/dist ./dist
COPY --from=builder /app/server.ts ./server.ts
COPY --from=builder /app/src/backend ./src/backend
EXPOSE 3000
CMD ["npx", "tsx", "server.ts"]`
  }
];
