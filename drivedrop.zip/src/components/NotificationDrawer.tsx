import React from 'react';
import { TransferRecord } from '../types';
import { Download, Upload, CheckCircle, AlertCircle, X, ChevronDown, Server, Zap } from 'lucide-react';

interface NotificationDrawerProps {
  isOpen: boolean;
  onToggle: () => void;
  activeTransfer: TransferRecord | null;
  onCancelTransfer: () => void;
}

export const NotificationDrawer: React.FC<NotificationDrawerProps> = ({
  isOpen,
  onToggle,
  activeTransfer,
  onCancelTransfer,
}) => {
  return (
    <div
      className={`absolute inset-x-0 top-0 z-30 transform rounded-t-[32px] bg-neutral-900/95 text-white backdrop-blur-md transition-all duration-300 ease-in-out ${
        isOpen ? 'translate-y-0 shadow-2xl' : '-translate-y-[calc(100%-28px)]'
      }`}
    >
      {/* Drawer Handle / Status Bar Pull */}
      <div
        onClick={onToggle}
        className="flex h-7 cursor-pointer items-center justify-between px-6 text-[11px] text-neutral-400 select-none hover:text-white"
      >
        <span className="font-mono">9:41</span>
        <div className="flex items-center gap-2">
          {activeTransfer && (
            <span className="flex items-center gap-1 text-blue-400">
              <Server className="h-3 w-3 animate-pulse" />
              <span>
                {activeTransfer.status === 'DOWNLOADING'
                  ? `Cloud DL: ${activeTransfer.downloadProgress}%`
                  : activeTransfer.status === 'UPLOADING'
                  ? `Drive UP: ${activeTransfer.uploadProgress}%`
                  : activeTransfer.status === 'QUEUED'
                  ? 'Queued'
                  : '100%'}
              </span>
            </span>
          )}
          <ChevronDown
            className={`h-3.5 w-3.5 transition-transform ${isOpen ? 'rotate-180' : ''}`}
          />
        </div>
      </div>

      {/* Expanded Notifications Panel */}
      {isOpen && (
        <div className="max-h-72 overflow-y-auto p-4 pt-1">
          <div className="mb-2 flex items-center justify-between px-1">
            <span className="text-xs font-semibold tracking-wider text-neutral-400 uppercase">
              Ongoing Notifications
            </span>
            <span className="text-[11px] text-emerald-400 font-mono flex items-center gap-1">
              <Zap className="h-3 w-3" />
              <span>0 MB Mobile Data</span>
            </span>
          </div>

          {activeTransfer ? (
            <div className="rounded-2xl border border-neutral-800 bg-neutral-800/80 p-3.5 shadow-lg">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-blue-600 text-white">
                    {activeTransfer.status === 'DOWNLOADING' ? (
                      <Download className="h-4 w-4 animate-bounce" />
                    ) : activeTransfer.status === 'UPLOADING' ? (
                      <Upload className="h-4 w-4 animate-pulse" />
                    ) : (
                      <CheckCircle className="h-4 w-4" />
                    )}
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-neutral-100">
                      Cloud Worker: {activeTransfer.fileName}
                    </div>
                    <div className="text-[11px] text-neutral-400">
                      Google Cloud Run → Google Drive
                    </div>
                  </div>
                </div>
                {(activeTransfer.status === 'DOWNLOADING' || activeTransfer.status === 'UPLOADING' || activeTransfer.status === 'QUEUED') && (
                  <button
                    type="button"
                    onClick={onCancelTransfer}
                    className="rounded-full p-1 text-neutral-400 hover:bg-neutral-700 hover:text-white"
                    title="Cancel Transfer"
                  >
                    <X className="h-4 w-4" />
                  </button>
                )}
              </div>

              {/* Progress Bar & Details */}
              <div className="mt-3">
                <div className="flex justify-between text-[11px] text-neutral-300">
                  <span>
                    {activeTransfer.status === 'QUEUED'
                      ? 'Job queued on cloud backend…'
                      : activeTransfer.status === 'DOWNLOADING'
                      ? `Cloud stream download (${activeTransfer.downloadProgress}%)`
                      : activeTransfer.status === 'UPLOADING'
                      ? `Google Drive resumable upload (${activeTransfer.uploadProgress}%)`
                      : '✓ Upload complete'}
                  </span>
                  <span className="font-mono font-bold text-blue-400">
                    {activeTransfer.status === 'DOWNLOADING'
                      ? `${activeTransfer.downloadProgress}%`
                      : `${activeTransfer.uploadProgress}%`}
                  </span>
                </div>
                <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-neutral-700">
                  <div
                    className="h-full bg-blue-500 transition-all duration-200"
                    style={{
                      width: `${
                        activeTransfer.status === 'DOWNLOADING'
                          ? activeTransfer.downloadProgress
                          : activeTransfer.uploadProgress
                      }%`,
                    }}
                  />
                </div>
              </div>
            </div>
          ) : (
            <div className="rounded-2xl border border-dashed border-neutral-800 p-4 text-center text-xs text-neutral-500">
              No active background transfers running.
            </div>
          )}
        </div>
      )}
    </div>
  );
};
