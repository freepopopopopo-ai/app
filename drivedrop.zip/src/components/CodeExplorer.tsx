import React, { useState } from 'react';
import { ANDROID_CODE_FILES, CodeFile } from '../data/codeFiles';
import { FileCode, Copy, Check, Terminal, ExternalLink } from 'lucide-react';

export const CodeExplorer: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<CodeFile>(ANDROID_CODE_FILES[0]);
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex h-[740px] flex-col overflow-hidden rounded-3xl border border-neutral-200 bg-white shadow-xl dark:border-neutral-800 dark:bg-neutral-900">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-neutral-200 bg-neutral-50 px-4 py-3 dark:border-neutral-800 dark:bg-neutral-950">
        <div className="flex items-center gap-2">
          <FileCode className="h-4 w-4 text-blue-600 dark:text-blue-400" />
          <span className="text-xs font-bold text-neutral-800 dark:text-neutral-200">
            Native Android Source Code Explorer
          </span>
        </div>
        <button
          onClick={handleCopy}
          className="flex items-center gap-1 rounded-lg border border-neutral-200 bg-white px-2.5 py-1 text-xs font-semibold text-neutral-700 shadow-2xs hover:bg-neutral-50 dark:border-neutral-800 dark:bg-neutral-800 dark:text-neutral-200 dark:hover:bg-neutral-700"
        >
          {copied ? (
            <>
              <Check className="h-3.5 w-3.5 text-green-600" />
              <span>Copied!</span>
            </>
          ) : (
            <>
              <Copy className="h-3.5 w-3.5" />
              <span>Copy File</span>
            </>
          )}
        </button>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar File List */}
        <div className="w-52 shrink-0 border-r border-neutral-200 bg-neutral-50/50 p-2 overflow-y-auto dark:border-neutral-800 dark:bg-neutral-950/40">
          <div className="px-2 py-1 text-[10px] font-bold text-neutral-400 uppercase tracking-wider">
            Kotlin & Manifest
          </div>
          <div className="space-y-1 mt-1">
            {ANDROID_CODE_FILES.map((file) => (
              <button
                key={file.path}
                onClick={() => setSelectedFile(file)}
                className={`flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-xs transition-all ${
                  selectedFile.path === file.path
                    ? 'bg-blue-600 font-semibold text-white shadow-xs'
                    : 'text-neutral-600 hover:bg-neutral-100 dark:text-neutral-400 dark:hover:bg-neutral-800/60'
                }`}
              >
                <span className="truncate">{file.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Code Viewer */}
        <div className="flex flex-1 flex-col overflow-hidden bg-neutral-900 text-neutral-100">
          <div className="border-b border-neutral-800 bg-neutral-950 px-4 py-2 text-xs text-neutral-400 font-mono flex items-center justify-between">
            <span className="truncate">{selectedFile.path}</span>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-neutral-800 text-neutral-300">
              {selectedFile.language.toUpperCase()}
            </span>
          </div>

          <div className="p-3 bg-neutral-800/40 border-b border-neutral-800 text-xs text-neutral-300">
            {selectedFile.description}
          </div>

          <pre className="flex-1 overflow-auto p-4 text-[11px] font-mono leading-relaxed text-neutral-200 select-all">
            <code>{selectedFile.content}</code>
          </pre>
        </div>
      </div>
    </div>
  );
};
