import React, { useState } from 'react';
import { X, Check, Copy, Terminal, Shield, ExternalLink, Server, Cloud, Smartphone, Code, Layers } from 'lucide-react';

interface SetupGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SetupGuideModal: React.FC<SetupGuideModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'cloudrun' | 'android' | 'env'>('cloudrun');
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const cloudRunCommands = [
    {
      title: '1. Set Google Cloud Project & Region',
      cmd: `gcloud config set project YOUR_PROJECT_ID\ngcloud config set run/region us-central1`,
    },
    {
      title: '2. Enable Cloud Run & Artifact Registry APIs',
      cmd: `gcloud services enable run.googleapis.com \\\n  artifactregistry.googleapis.com \\\n  drive.googleapis.com`,
    },
    {
      title: '3. Build & Deploy Backend Container to Cloud Run',
      cmd: `gcloud run deploy drivedrop-backend \\\n  --source . \\\n  --platform managed \\\n  --region us-central1 \\\n  --allow-unauthenticated \\\n  --memory 1Gi \\\n  --cpu 1 \\\n  --timeout 3600`,
    },
    {
      title: '4. Test Backend Health & API',
      cmd: `curl -X GET https://drivedrop-backend-YOUR_HASH-uc.a.run.app/api/health`,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-xs">
      <div className="flex max-h-[92vh] w-full max-w-3xl flex-col overflow-hidden rounded-3xl bg-white shadow-2xl dark:bg-[#1A1A1A] dark:text-white border border-neutral-200 dark:border-neutral-800">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-neutral-200 p-5 dark:border-neutral-800">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-blue-50 text-blue-600 dark:bg-blue-950 dark:text-blue-400">
              <Server className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-bold">DriveDrop Architecture & Deployment Guide</h3>
              <p className="text-xs text-neutral-500">Google Cloud Run Backend + Native Android App</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-full p-1.5 text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-neutral-200 bg-neutral-50 px-6 dark:border-neutral-800 dark:bg-neutral-900">
          <button
            onClick={() => setActiveTab('cloudrun')}
            className={`flex items-center gap-2 border-b-2 px-4 py-3 text-xs font-bold transition ${
              activeTab === 'cloudrun'
                ? 'border-[#1A73E8] text-[#1A73E8]'
                : 'border-transparent text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            <Server className="h-4 w-4" />
            <span>Google Cloud Run (Backend)</span>
          </button>
          <button
            onClick={() => setActiveTab('android')}
            className={`flex items-center gap-2 border-b-2 px-4 py-3 text-xs font-bold transition ${
              activeTab === 'android'
                ? 'border-[#1A73E8] text-[#1A73E8]'
                : 'border-transparent text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            <Smartphone className="h-4 w-4" />
            <span>Android App Studio Build</span>
          </button>
          <button
            onClick={() => setActiveTab('env')}
            className={`flex items-center gap-2 border-b-2 px-4 py-3 text-xs font-bold transition ${
              activeTab === 'env'
                ? 'border-[#1A73E8] text-[#1A73E8]'
                : 'border-transparent text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            <Shield className="h-4 w-4" />
            <span>Secrets & Testing</span>
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-sm">
          {activeTab === 'cloudrun' && (
            <div className="space-y-4">
              <div className="rounded-2xl bg-blue-50/80 p-4 border border-blue-100 dark:border-blue-900/40 dark:bg-blue-950/40 text-xs text-blue-900 dark:text-blue-200">
                <strong>Why Cloud Run for Option 2?</strong><br />
                Cloud Run executes the entire file download from the direct URL and streams chunks into Google Drive Resumable Upload sessions. The Android phone only sends the URL and receives status updates (0 MB phone data used).
              </div>

              {cloudRunCommands.map((item, idx) => (
                <div key={idx} className="space-y-1.5">
                  <div className="text-xs font-bold text-neutral-700 dark:text-neutral-300">
                    {item.title}
                  </div>
                  <div className="relative rounded-xl bg-neutral-900 p-3 font-mono text-xs text-emerald-400">
                    <pre className="overflow-x-auto whitespace-pre-wrap">{item.cmd}</pre>
                    <button
                      onClick={() => copyToClipboard(item.cmd, idx)}
                      className="absolute top-2.5 right-2.5 rounded-lg bg-neutral-800 p-1.5 text-neutral-400 hover:text-white"
                      title="Copy command"
                    >
                      {copiedIndex === idx ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'android' && (
            <div className="space-y-4">
              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase text-neutral-500">1. Connecting Android App to Backend</h4>
                <p className="text-xs text-neutral-600 dark:text-neutral-300">
                  In <code className="text-blue-500 font-mono">app/src/main/java/.../CloudApiService.kt</code>, set the backend URL:
                </p>
                <div className="rounded-xl bg-neutral-900 p-3 font-mono text-xs text-neutral-200">
                  <code>const val BACKEND_URL = &quot;https://drivedrop-backend-YOUR_HASH-uc.a.run.app&quot;</code>
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase text-neutral-500">2. Google Cloud OAuth for Android</h4>
                <div className="rounded-xl bg-neutral-50 p-4 dark:bg-neutral-800/80 text-xs space-y-2">
                  <p>In Google Cloud Console &gt; Credentials &gt; OAuth 2.0 Client IDs:</p>
                  <ul className="list-disc list-inside space-y-1 text-neutral-600 dark:text-neutral-300 font-mono text-[11px]">
                    <li>Type: <strong>Android</strong></li>
                    <li>Package Name: <strong>com.drivedrop.app</strong></li>
                    <li>SHA-1 Fingerprint: from <code className="text-blue-400">./gradlew signingReport</code></li>
                  </ul>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'env' && (
            <div className="space-y-4 text-xs">
              <div className="space-y-2">
                <h4 className="font-bold text-neutral-800 dark:text-neutral-200">Testing with Small &amp; Large Files</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="rounded-xl border border-neutral-200 p-3 dark:border-neutral-800">
                    <div className="font-bold text-neutral-900 dark:text-neutral-100">Small File Test (Sample PDF, ~1.2 MB)</div>
                    <code className="text-[10px] text-blue-500 block truncate mt-1">
                      https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf
                    </code>
                    <p className="text-[11px] text-neutral-500 mt-1">Verifies instant URL validation, filename extraction, and immediate upload.</p>
                  </div>
                  <div className="rounded-xl border border-neutral-200 p-3 dark:border-neutral-800">
                    <div className="font-bold text-neutral-900 dark:text-neutral-100">Large File Test (Big Buck Bunny 1080p, ~158 MB)</div>
                    <code className="text-[10px] text-blue-500 block truncate mt-1">
                      https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4
                    </code>
                    <p className="text-[11px] text-neutral-500 mt-1">Verifies chunked streaming pipeline and Google Drive Resumable Upload sessions.</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-neutral-200 bg-neutral-50 p-4 dark:border-neutral-800 dark:bg-neutral-950 flex justify-end">
          <button
            onClick={onClose}
            className="rounded-xl bg-[#1A73E8] px-5 py-2 text-xs font-semibold text-white hover:bg-blue-700"
          >
            Close Guide
          </button>
        </div>
      </div>
    </div>
  );
};
