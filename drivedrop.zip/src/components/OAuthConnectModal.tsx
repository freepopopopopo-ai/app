import React, { useState } from 'react';
import { GoogleAccount } from '../types';
import { Check, Shield, User, Key, ExternalLink, Sparkles } from 'lucide-react';

interface OAuthConnectModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConnect: (account: GoogleAccount) => void;
}

export const OAuthConnectModal: React.FC<OAuthConnectModalProps> = ({
  isOpen,
  onClose,
  onConnect,
}) => {
  const [activeTab, setActiveTab] = useState<'demo' | 'real'>('demo');
  const [selectedAccount, setSelectedAccount] = useState<string>('alex.morgan@gmail.com');
  const [customEmail, setCustomEmail] = useState('');
  const [isCustom, setIsCustom] = useState(false);
  const [realToken, setRealToken] = useState('');
  const [realEmail, setRealEmail] = useState('');

  if (!isOpen) return null;

  const accounts = [
    {
      email: 'alex.morgan@gmail.com',
      name: 'Alex Morgan',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80',
    },
    {
      email: 'alex.work@company.com',
      name: 'Alex (Work)',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80',
    },
  ];

  const handleConfirm = () => {
    if (activeTab === 'real') {
      const email = realEmail.trim() || 'my.google.account@gmail.com';
      onConnect({
        email,
        displayName: email.split('@')[0],
        isConnected: true,
        lastConnectedTime: Date.now(),
        accessToken: realToken.trim() || undefined,
      });
      onClose();
      return;
    }

    if (isCustom && customEmail) {
      onConnect({
        email: customEmail,
        displayName: customEmail.split('@')[0],
        isConnected: true,
        lastConnectedTime: Date.now(),
        accessToken: 'sim_' + Date.now(),
      });
    } else {
      const acc = accounts.find((a) => a.email === selectedAccount) || accounts[0];
      onConnect({
        email: acc.email,
        displayName: acc.name,
        photoUrl: acc.avatar,
        isConnected: true,
        lastConnectedTime: Date.now(),
        accessToken: 'sim_' + Date.now(),
      });
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
      <div className="w-full max-w-md overflow-hidden rounded-3xl bg-white shadow-2xl transition-all dark:bg-neutral-900 dark:text-white">
        {/* Google Header */}
        <div className="border-b border-neutral-100 p-5 text-center dark:border-neutral-800">
          <div className="mx-auto flex h-10 w-10 items-center justify-center rounded-full bg-blue-50 text-blue-600 dark:bg-blue-950 dark:text-blue-400">
            <svg className="h-6 w-6" viewBox="0 0 24 24">
              <path
                fill="currentColor"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="#34A853"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="#FBBC05"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
              />
              <path
                fill="#EA4335"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
              />
            </svg>
          </div>
          <h3 className="mt-3 text-lg font-semibold tracking-tight">Connect Google Drive</h3>
          <p className="text-xs text-neutral-500 dark:text-neutral-400">
            to stream direct URLs into your <strong className="text-neutral-800 dark:text-neutral-200">DriveDrop</strong> folder
          </p>

          {/* Mode Switcher */}
          <div className="mt-4 flex rounded-xl bg-neutral-100 p-1 dark:bg-neutral-800">
            <button
              type="button"
              onClick={() => setActiveTab('demo')}
              className={`flex-1 rounded-lg py-1.5 text-xs font-semibold transition-all ${
                activeTab === 'demo'
                  ? 'bg-white text-neutral-900 shadow-xs dark:bg-neutral-700 dark:text-white'
                  : 'text-neutral-600 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-white'
              }`}
            >
              <span className="flex items-center justify-center gap-1.5">
                <Sparkles className="h-3.5 w-3.5 text-amber-500" />
                Demo Account
              </span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('real')}
              className={`flex-1 rounded-lg py-1.5 text-xs font-semibold transition-all ${
                activeTab === 'real'
                  ? 'bg-white text-neutral-900 shadow-xs dark:bg-neutral-700 dark:text-white'
                  : 'text-neutral-600 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-white'
              }`}
            >
              <span className="flex items-center justify-center gap-1.5">
                <Key className="h-3.5 w-3.5 text-blue-500" />
                Real Google Token
              </span>
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-5">
          {activeTab === 'demo' ? (
            <div className="space-y-2.5">
              {accounts.map((acc) => (
                <button
                  key={acc.email}
                  type="button"
                  onClick={() => {
                    setSelectedAccount(acc.email);
                    setIsCustom(false);
                  }}
                  className={`flex w-full items-center gap-3 rounded-2xl p-3 text-left transition-all ${
                    selectedAccount === acc.email && !isCustom
                      ? 'border-2 border-blue-500 bg-blue-50/60 dark:border-blue-500 dark:bg-blue-950/40'
                      : 'border border-neutral-200 hover:bg-neutral-50 dark:border-neutral-800 dark:hover:bg-neutral-800/60'
                  }`}
                >
                  <img
                    src={acc.avatar}
                    alt={acc.name}
                    className="h-10 w-10 rounded-full object-cover ring-2 ring-white dark:ring-neutral-800"
                  />
                  <div className="flex-1 overflow-hidden">
                    <div className="text-sm font-semibold text-neutral-900 dark:text-neutral-100">{acc.name}</div>
                    <div className="truncate text-xs text-neutral-500 dark:text-neutral-400">{acc.email}</div>
                  </div>
                  {selectedAccount === acc.email && !isCustom && (
                    <Check className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                  )}
                </button>
              ))}

              <button
                type="button"
                onClick={() => setIsCustom(true)}
                className={`flex w-full items-center gap-3 rounded-2xl p-3 text-left transition-all ${
                  isCustom
                    ? 'border-2 border-blue-500 bg-blue-50/60 dark:border-blue-500 dark:bg-blue-950/40'
                    : 'border border-neutral-200 hover:bg-neutral-50 dark:border-neutral-800 dark:hover:bg-neutral-800/60'
                }`}
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-neutral-100 text-neutral-600 dark:bg-neutral-800 dark:text-neutral-300">
                  <User className="h-5 w-5" />
                </div>
                <div className="flex-1">
                  <div className="text-sm font-semibold text-neutral-900 dark:text-neutral-100">Custom email label</div>
                  <div className="text-xs text-neutral-500 dark:text-neutral-400">Enter your email</div>
                </div>
              </button>

              {isCustom && (
                <input
                  type="email"
                  placeholder="your.email@gmail.com"
                  value={customEmail}
                  onChange={(e) => setCustomEmail(e.target.value)}
                  className="mt-2 w-full rounded-xl border border-neutral-300 px-3.5 py-2 text-sm focus:border-blue-500 focus:outline-hidden dark:border-neutral-700 dark:bg-neutral-800"
                  autoFocus
                />
              )}
            </div>
          ) : (
            <div className="space-y-3 text-left">
              <div>
                <label className="text-xs font-semibold text-neutral-700 dark:text-neutral-300">
                  Your Google Email
                </label>
                <input
                  type="email"
                  placeholder="yourname@gmail.com"
                  value={realEmail}
                  onChange={(e) => setRealEmail(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-neutral-300 px-3.5 py-2 text-sm focus:border-blue-500 focus:outline-hidden dark:border-neutral-700 dark:bg-neutral-800"
                />
              </div>

              <div>
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-neutral-700 dark:text-neutral-300">
                    Google OAuth Access Token (Bearer)
                  </label>
                  <a
                    href="https://developers.google.com/oauthplayground"
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1 text-[11px] font-semibold text-blue-600 hover:underline dark:text-blue-400"
                  >
                    Get instant token <ExternalLink className="h-3 w-3" />
                  </a>
                </div>
                <textarea
                  rows={3}
                  placeholder="Paste Bearer token (ya29.a0...)"
                  value={realToken}
                  onChange={(e) => setRealToken(e.target.value)}
                  className="mt-1 w-full font-mono text-xs rounded-xl border border-neutral-300 px-3.5 py-2 focus:border-blue-500 focus:outline-hidden dark:border-neutral-700 dark:bg-neutral-800"
                />
                <p className="mt-1 text-[11px] text-neutral-500 dark:text-neutral-400">
                  From OAuth Playground with scope: <code className="text-blue-600 dark:text-blue-400">https://www.googleapis.com/auth/drive.file</code>
                </p>
              </div>
            </div>
          )}

          {/* Scope transparency notice */}
          <div className="mt-4 rounded-xl bg-neutral-100 p-3 text-[11px] text-neutral-600 dark:bg-neutral-800 dark:text-neutral-300">
            <div className="flex items-start gap-2">
              <Shield className="mt-0.5 h-3.5 w-3.5 shrink-0 text-green-600 dark:text-green-400" />
              <span>
                <strong>Requested Scope:</strong> <code className="text-blue-600 dark:text-blue-400">drive.file</code> (only creates & manages files inside the <code className="font-semibold text-neutral-800 dark:text-neutral-200">DriveDrop/</code> folder).
              </span>
            </div>
          </div>

          {/* Actions */}
          <div className="mt-5 flex gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 rounded-xl border border-neutral-300 py-2.5 text-xs font-semibold text-neutral-700 hover:bg-neutral-100 dark:border-neutral-700 dark:text-neutral-300 dark:hover:bg-neutral-800"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleConfirm}
              className="flex-1 rounded-xl bg-blue-600 py-2.5 text-xs font-semibold text-white shadow-sm hover:bg-blue-700"
            >
              Allow & Connect
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

