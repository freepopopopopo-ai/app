import React, { useState, useEffect } from 'react';
import { Play, RefreshCw, Send, CheckCircle, AlertCircle, Copy, Check, Terminal } from 'lucide-react';

export const ApiWorkbench: React.FC = () => {
  const [method, setMethod] = useState<'POST' | 'GET'>('POST');
  const [endpoint, setEndpoint] = useState('/api/upload');
  const [requestBody, setRequestBody] = useState(
    JSON.stringify(
      {
        url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
        folderName: 'DriveDrop',
        customFileName: 'ForBiggerBlazes.mp4',
      },
      null,
      2
    )
  );
  const [responseStatus, setResponseStatus] = useState<number | null>(null);
  const [responseHeaders, setResponseHeaders] = useState<any>(null);
  const [responseBody, setResponseBody] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const predefinedTests = [
    {
      name: 'POST /api/upload (Start Transfer)',
      method: 'POST',
      endpoint: '/api/upload',
      body: JSON.stringify(
        {
          url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
          folderName: 'DriveDrop',
          customFileName: 'ForBiggerBlazes.mp4',
        },
        null,
        2
      ),
    },
    {
      name: 'GET /api/jobs (List All Jobs)',
      method: 'GET',
      endpoint: '/api/jobs',
      body: '',
    },
    {
      name: 'GET /api/health (Health Check)',
      method: 'GET',
      endpoint: '/api/health',
      body: '',
    },
  ];

  const handleExecute = async () => {
    setIsLoading(true);
    setResponseStatus(null);
    setResponseBody('');
    try {
      const options: RequestInit = {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
      };
      if (method === 'POST' && requestBody) {
        options.body = requestBody;
      }

      const res = await fetch(endpoint, options);
      setResponseStatus(res.status);
      const data = await res.json().catch(() => ({}));
      setResponseBody(JSON.stringify(data, null, 2));
    } catch (err: any) {
      setResponseStatus(500);
      setResponseBody(JSON.stringify({ error: err.message || 'Request failed' }, null, 2));
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyResponse = () => {
    navigator.clipboard.writeText(responseBody);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="rounded-3xl border border-neutral-200 bg-white p-6 shadow-sm dark:border-neutral-800 dark:bg-neutral-900 space-y-6">
      <div className="flex items-center justify-between border-b border-neutral-100 pb-4 dark:border-neutral-800">
        <div>
          <h3 className="text-sm font-bold text-neutral-900 dark:text-white flex items-center gap-2">
            <Terminal className="h-4 w-4 text-blue-600" />
            <span>Interactive Cloud REST API Workbench</span>
          </h3>
          <p className="text-xs text-neutral-500">
            Directly test and inspect endpoints exposed by the DriveDrop Cloud Run backend.
          </p>
        </div>
      </div>

      {/* Quick Preset Buttons */}
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-xs font-semibold text-neutral-400">Presets:</span>
        {predefinedTests.map((t) => (
          <button
            key={t.name}
            onClick={() => {
              setMethod(t.method as any);
              setEndpoint(t.endpoint);
              setRequestBody(t.body);
            }}
            className="rounded-xl border border-neutral-200 bg-neutral-50 px-3 py-1.5 text-xs font-medium hover:border-blue-500 hover:bg-blue-50 dark:border-neutral-700 dark:bg-neutral-800 dark:hover:bg-neutral-700"
          >
            {t.name}
          </button>
        ))}
      </div>

      {/* Request Form */}
      <div className="space-y-3">
        <div className="flex gap-2">
          <select
            value={method}
            onChange={(e) => setMethod(e.target.value as any)}
            className="rounded-xl border border-neutral-300 bg-neutral-50 px-3 py-2 text-xs font-bold text-neutral-800 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-200"
          >
            <option value="POST">POST</option>
            <option value="GET">GET</option>
          </select>
          <input
            type="text"
            value={endpoint}
            onChange={(e) => setEndpoint(e.target.value)}
            className="flex-1 rounded-xl border border-neutral-300 px-3 py-2 font-mono text-xs text-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-white"
          />
          <button
            onClick={handleExecute}
            disabled={isLoading}
            className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-blue-700 disabled:opacity-50"
          >
            {isLoading ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
            <span>Execute</span>
          </button>
        </div>

        {method === 'POST' && (
          <div className="space-y-1">
            <label className="text-[11px] font-semibold text-neutral-500">JSON Request Body:</label>
            <textarea
              rows={5}
              value={requestBody}
              onChange={(e) => setRequestBody(e.target.value)}
              className="w-full rounded-xl border border-neutral-300 bg-neutral-950 p-3 font-mono text-xs text-emerald-400 dark:border-neutral-700"
            />
          </div>
        )}
      </div>

      {/* Response Panel */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-neutral-700 dark:text-neutral-300">HTTP Response</span>
            {responseStatus !== null && (
              <span
                className={`rounded-full px-2 py-0.5 text-[10px] font-mono font-bold ${
                  responseStatus >= 200 && responseStatus < 300
                    ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                    : 'bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300'
                }`}
              >
                Status: {responseStatus}
              </span>
            )}
          </div>
          {responseBody && (
            <button
              onClick={handleCopyResponse}
              className="flex items-center gap-1 text-[11px] text-neutral-500 hover:text-neutral-900 dark:hover:text-white"
            >
              {copied ? <Check className="h-3 w-3 text-emerald-500" /> : <Copy className="h-3 w-3" />}
              <span>Copy Response</span>
            </button>
          )}
        </div>

        <pre className="max-h-60 overflow-auto rounded-2xl bg-neutral-950 p-4 font-mono text-xs text-neutral-200 border border-neutral-800">
          {responseBody || '// Response JSON will appear here after executing request'}
        </pre>
      </div>
    </div>
  );
};
