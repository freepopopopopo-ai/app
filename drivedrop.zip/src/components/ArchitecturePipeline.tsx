import React, { useState, useEffect } from 'react';
import { TransferRecord, CloudJob } from '../types';
import {
  Smartphone,
  Server,
  Cloud,
  ArrowRight,
  Zap,
  CheckCircle2,
  Activity,
  HardDrive,
  Cpu,
  Layers,
  ShieldCheck,
  RefreshCw,
} from 'lucide-react';

interface ArchitecturePipelineProps {
  activeTransfer: TransferRecord | null;
}

export const ArchitecturePipeline: React.FC<ArchitecturePipelineProps> = ({ activeTransfer }) => {
  const [cloudJobs, setCloudJobs] = useState<CloudJob[]>([]);
  const [healthStatus, setHealthStatus] = useState<any>(null);

  useEffect(() => {
    const fetchTelemetry = async () => {
      try {
        const [jobsRes, healthRes] = await Promise.all([
          fetch('/api/jobs'),
          fetch('/api/health'),
        ]);
        if (jobsRes.ok) {
          const data = await jobsRes.json();
          setCloudJobs(data.jobs || []);
        }
        if (healthRes.ok) {
          const health = await healthRes.json();
          setHealthStatus(health);
        }
      } catch (e) {}
    };

    fetchTelemetry();
    const interval = setInterval(fetchTelemetry, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-6">
      {/* 1. Visual Architecture Flow Diagram */}
      <div className="rounded-3xl border border-neutral-200 bg-white p-6 shadow-sm dark:border-neutral-800 dark:bg-neutral-900">
        <div className="flex items-center justify-between pb-4 border-b border-neutral-100 dark:border-neutral-800">
          <div>
            <h3 className="text-sm font-bold text-neutral-900 dark:text-white flex items-center gap-2">
              <Layers className="h-4 w-4 text-blue-600" />
              <span>Option 2: Cloud-Mediated Direct File Streaming</span>
            </h3>
            <p className="text-xs text-neutral-500">
              The phone acts as a control plane only; the heavy payload streams directly from source to Google Drive.
            </p>
          </div>
          <div className="flex items-center gap-2 rounded-full bg-emerald-50 px-3 py-1 text-xs font-bold text-emerald-700 border border-emerald-200 dark:bg-emerald-950/40 dark:border-emerald-900 dark:text-emerald-300">
            <span className="h-2 w-2 rounded-full bg-emerald-500 animate-ping" />
            <span>Option 2 Active</span>
          </div>
        </div>

        {/* 3-Node Architecture Flow Diagram */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 my-6">
          {/* Node 1: Android Phone */}
          <div className="rounded-2xl border border-neutral-200 p-4 bg-neutral-50/50 dark:border-neutral-800 dark:bg-neutral-950/50 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300">
                <Smartphone className="h-5 w-5" />
              </div>
              <span className="text-[10px] font-mono font-bold bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200 px-2 py-0.5 rounded-full">
                Phone: &lt; 1 KB Data
              </span>
            </div>
            <div className="font-bold text-xs">1. Android Device</div>
            <p className="text-[11px] text-neutral-500 leading-relaxed">
              • User enters or shares Direct URL.<br />
              • Sends lightweight POST <code className="text-blue-500">/api/upload</code>.<br />
              • Receives status polling responses.<br />
              • <strong>0 MB downloaded on phone.</strong>
            </p>
          </div>

          {/* Node 2: Cloud Backend */}
          <div className="rounded-2xl border-2 border-blue-500/50 p-4 bg-blue-50/30 dark:border-blue-700/50 dark:bg-blue-950/20 space-y-2 relative">
            <div className="flex items-center justify-between">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-blue-600 text-white shadow-xs">
                <Server className="h-5 w-5" />
              </div>
              <span className="text-[10px] font-mono font-bold bg-emerald-500 text-white px-2 py-0.5 rounded-full animate-pulse">
                Streaming Pipeline
              </span>
            </div>
            <div className="font-bold text-xs text-blue-900 dark:text-blue-200">
              2. Google Cloud Run Backend
            </div>
            <p className="text-[11px] text-neutral-600 dark:text-neutral-400 leading-relaxed">
              • Opens HTTP stream to direct URL.<br />
              • Reads chunks into transient stream buffers.<br />
              • Initiates Google Drive Resumable Upload.<br />
              • Streams chunks with <code className="text-blue-500">Content-Range</code>.
            </p>
          </div>

          {/* Node 3: Google Drive */}
          <div className="rounded-2xl border border-neutral-200 p-4 bg-neutral-50/50 dark:border-neutral-800 dark:bg-neutral-950/50 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300">
                <Cloud className="h-5 w-5" />
              </div>
              <span className="text-[10px] font-mono font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200 px-2 py-0.5 rounded-full">
                Final Target
              </span>
            </div>
            <div className="font-bold text-xs">3. Google Drive API</div>
            <p className="text-[11px] text-neutral-500 leading-relaxed">
              • Receives resumable chunks at full speed.<br />
              • Stores file in <code className="text-emerald-600">DriveDrop/</code> folder.<br />
              • Generates permanent Google Drive File ID.<br />
              • Completes upload successfully.
            </p>
          </div>
        </div>

        {/* Live Active Stream Visualizer */}
        {activeTransfer && activeTransfer.status !== 'IDLE' && (
          <div className="rounded-2xl bg-neutral-900 text-white p-4 space-y-3 font-mono text-xs">
            <div className="flex items-center justify-between text-neutral-400 text-[11px]">
              <span className="flex items-center gap-1.5 text-emerald-400">
                <Activity className="h-3.5 w-3.5 animate-spin" />
                <span>Live Streaming Telemetry</span>
              </span>
              <span>Job: {activeTransfer.jobId || 'N/A'}</span>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-[11px]">
              <div>
                <span className="text-neutral-500 block">Status</span>
                <span className="text-blue-400 font-bold">{activeTransfer.status}</span>
              </div>
              <div>
                <span className="text-neutral-500 block">Cloud Download</span>
                <span className="text-white font-bold">{activeTransfer.downloadProgress}%</span>
              </div>
              <div>
                <span className="text-neutral-500 block">Drive Upload</span>
                <span className="text-emerald-400 font-bold">{activeTransfer.uploadProgress}%</span>
              </div>
              <div>
                <span className="text-neutral-500 block">Phone Mobile Data</span>
                <span className="text-emerald-400 font-bold">0 MB (Zero)</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 2. Cloud Backend Health & Job Monitor */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Backend Runtime Stats */}
        <div className="rounded-3xl border border-neutral-200 bg-white p-5 shadow-sm dark:border-neutral-800 dark:bg-neutral-900 space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-500 flex items-center gap-1.5">
              <Cpu className="h-4 w-4 text-blue-600" />
              <span>Cloud Run Health &amp; Specs</span>
            </h4>
            <span className="h-2 w-2 rounded-full bg-emerald-500" />
          </div>
          <div className="space-y-2 text-xs">
            <div className="flex justify-between py-1 border-b border-neutral-100 dark:border-neutral-800">
              <span className="text-neutral-500">Service</span>
              <span className="font-semibold">{healthStatus?.service || 'DriveDrop-Cloud-Worker'}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-neutral-100 dark:border-neutral-800">
              <span className="text-neutral-500">Environment</span>
              <span className="font-semibold">{healthStatus?.platform || 'Google Cloud Run'}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-neutral-100 dark:border-neutral-800">
              <span className="text-neutral-500">Memory Strategy</span>
              <span className="font-semibold text-emerald-600">Streaming (Chunked, Zero Whole-File RAM)</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-neutral-500">Total Jobs Handled</span>
              <span className="font-semibold">{cloudJobs.length}</span>
            </div>
          </div>
        </div>

        {/* Security & Token Isolation */}
        <div className="rounded-3xl border border-neutral-200 bg-white p-5 shadow-sm dark:border-neutral-800 dark:bg-neutral-900 space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-500 flex items-center gap-1.5">
              <ShieldCheck className="h-4 w-4 text-emerald-600" />
              <span>Security &amp; Token Architecture</span>
            </h4>
          </div>
          <p className="text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed">
            • <strong>No Client Secrets on Android:</strong> The Android app authenticates via Google Identity Services and passes short-lived OAuth Bearer tokens in headers.<br />
            • <strong>Scoped Authorization:</strong> Only requests the restrictive <code className="text-blue-500">drive.file</code> scope.<br />
            • <strong>SSRF Protection:</strong> Cloud worker rejects internal loopbacks (127.0.0.1, 169.254.169.254, RFC-1918 private subnets).
          </p>
        </div>
      </div>
    </div>
  );
};
