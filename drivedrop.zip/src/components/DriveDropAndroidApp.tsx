import React, { useState, useEffect, useRef } from 'react';
import { GoogleAccount, TransferRecord, TransferStatus, JobStatusResponse } from '../types';
import { SAMPLE_URLS } from '../data/sampleUrls';
import {
  Cloud,
  CloudUpload,
  Link as LinkIcon,
  Settings as SettingsIcon,
  ArrowLeft,
  CheckCircle,
  AlertCircle,
  Trash2,
  RefreshCw,
  Folder,
  Lock,
  Info,
  LogOut,
  X,
  Sparkles,
  ExternalLink,
  Layers,
  Server,
  Zap,
  Activity,
  Smartphone,
} from 'lucide-react';

interface DriveDropAndroidAppProps {
  onOpenOAuth: () => void;
  onOpenShareSheet: () => void;
  googleAccount: GoogleAccount | null;
  onDisconnectDrive: () => void;
  initialUrl?: string;
  onActiveTransferChange?: (transfer: TransferRecord | null) => void;
}

export const DriveDropAndroidApp: React.FC<DriveDropAndroidAppProps> = ({
  onOpenOAuth,
  onOpenShareSheet,
  googleAccount,
  onDisconnectDrive,
  initialUrl = '',
  onActiveTransferChange,
}) => {
  const [currentScreen, setCurrentScreen] = useState<'main' | 'settings'>('main');
  const [urlInput, setUrlInput] = useState(initialUrl);
  const [urlError, setUrlError] = useState<string | null>(null);
  const [isStarting, setIsStarting] = useState(false);
  const [folderName, setFolderName] = useState('DriveDrop');

  // Transfers and History State (Simulating Room Database synced with Cloud Backend)
  const [activeTransfer, setActiveTransfer] = useState<TransferRecord | null>(null);
  const [history, setHistory] = useState<TransferRecord[]>(() => {
    const saved = localStorage.getItem('drivedrop_cloud_history');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return [];
      }
    }
    return [
      {
        id: 'seed-cloud-1',
        jobId: 'job_sample_cloud_01',
        directUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
        fileName: 'BigBuckBunny.mp4',
        fileSizeBytes: 158000000,
        mimeType: 'video/mp4',
        status: 'UPLOAD_COMPLETED',
        downloadProgress: 100,
        uploadProgress: 100,
        driveFileId: '1AbC9dE_FghIjKlMnOpQrStUvWxYz1234',
        driveFolderPath: 'DriveDrop',
        createdAtTimestamp: Date.now() - 3600000 * 2,
        completedAtTimestamp: Date.now() - 3600000 * 2 + 15000,
        phoneDataUsedBytes: 0,
        cloudTransferredBytes: 158000000,
      },
    ];
  });

  const activePollingRef = useRef<number | null>(null);

  // Sync initial URL if provided from ShareSheet
  useEffect(() => {
    if (initialUrl) {
      setUrlInput(initialUrl);
      setUrlError(null);
    }
  }, [initialUrl]);

  // Persist history to localStorage
  useEffect(() => {
    localStorage.setItem('drivedrop_cloud_history', JSON.stringify(history));
  }, [history]);

  // Notify parent of active transfer
  useEffect(() => {
    if (onActiveTransferChange) {
      onActiveTransferChange(activeTransfer);
    }
  }, [activeTransfer, onActiveTransferChange]);

  // On mount: check if there's any active cloud job running on backend
  useEffect(() => {
    const fetchBackendJobs = async () => {
      try {
        const res = await fetch('/api/jobs');
        if (res.ok) {
          const data = await res.json();
          const running = data.jobs?.find(
            (j: any) => j.status === 'DOWNLOADING' || j.status === 'UPLOADING' || j.status === 'QUEUED'
          );
          if (running && !activeTransfer) {
            pollJobStatus(running.jobId, {
              id: 'tx-' + running.jobId,
              jobId: running.jobId,
              directUrl: running.url,
              fileName: running.fileName,
              fileSizeBytes: running.fileSizeBytes,
              mimeType: running.mimeType,
              status: running.status as TransferStatus,
              downloadProgress: running.downloadProgress,
              uploadProgress: running.uploadProgress,
              driveFolderPath: running.driveFolderPath,
              createdAtTimestamp: running.createdAt,
              phoneDataUsedBytes: 0,
            });
          }
        }
      } catch (e) {
        // Dev offline or fallback
      }
    };
    fetchBackendJobs();

    return () => {
      if (activePollingRef.current) {
        clearInterval(activePollingRef.current);
      }
    };
  }, []);

  /**
   * Option 2: Send URL to Cloud Backend (POST /api/upload)
   * The Android phone uses 0 MB data for the file transfer!
   */
  const startTransferProcess = async (url: string) => {
    const cleanUrl = url.trim();
    if (!cleanUrl || (!cleanUrl.startsWith('http://') && !cleanUrl.startsWith('https://'))) {
      setUrlError('Please enter a valid HTTP or HTTPS direct download URL');
      return;
    }

    if (!googleAccount?.isConnected) {
      onOpenOAuth();
      return;
    }

    setIsStarting(true);
    setUrlError(null);

    try {
      // 1. Submit URL to Cloud Backend
      const res = await fetch('/api/upload', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(googleAccount.accessToken ? { Authorization: `Bearer ${googleAccount.accessToken}` } : {}),
        },
        body: JSON.stringify({
          url: cleanUrl,
          folderName,
          googleAccessToken: googleAccount.accessToken,
        }),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.message || `Cloud server returned error (${res.status})`);
      }

      const data = await res.json();
      const jobId = data.jobId;

      const initialRecord: TransferRecord = {
        id: 'tx-' + Date.now(),
        jobId,
        directUrl: cleanUrl,
        fileName: data.fileName || 'file_download',
        fileSizeBytes: 0,
        mimeType: 'application/octet-stream',
        status: 'QUEUED',
        downloadProgress: 0,
        uploadProgress: 0,
        driveFolderPath: folderName,
        createdAtTimestamp: Date.now(),
        phoneDataUsedBytes: 0,
        cloudTransferredBytes: 0,
      };

      setActiveTransfer(initialRecord);
      setUrlInput('');
      setIsStarting(false);

      // 2. Start lightweight status polling from Cloud Backend (only JSON metadata)
      pollJobStatus(jobId, initialRecord);
    } catch (err: any) {
      setIsStarting(false);
      setUrlError(err.message || 'Failed to submit URL to cloud backend');
    }
  };

  const pollJobStatus = (jobId: string, baseRecord: TransferRecord) => {
    if (activePollingRef.current) {
      clearInterval(activePollingRef.current);
    }

    activePollingRef.current = window.setInterval(async () => {
      try {
        const res = await fetch(`/api/upload/${jobId}/status`);
        if (!res.ok) {
          throw new Error(`Failed to query job status (${res.status})`);
        }

        const data: JobStatusResponse = await res.json();

        setActiveTransfer((prev) => {
          if (!prev) return prev;

          const updated: TransferRecord = {
            ...prev,
            status: data.status,
            fileName: data.fileName || prev.fileName,
            fileSizeBytes: data.fileSizeBytes || prev.fileSizeBytes,
            mimeType: data.mimeType || prev.mimeType,
            downloadProgress: data.downloadProgress,
            uploadProgress: data.uploadProgress,
            errorMessage: data.error,
            driveFileId: data.driveFileId,
            phoneDataUsedBytes: 0, // Option 2 requirement: ALWAYS 0 bytes phone data
            cloudTransferredBytes: data.fileSizeBytes || 1024 * 1024 * 50,
          };

          if (data.status === 'UPLOAD_COMPLETED' || data.status === 'COMPLETED') {
            if (activePollingRef.current) clearInterval(activePollingRef.current);
            const finalized: TransferRecord = {
              ...updated,
              status: 'UPLOAD_COMPLETED',
              completedAtTimestamp: data.completedAt || Date.now(),
            };
            setHistory((old) => [finalized, ...old.filter((h) => h.id !== finalized.id && h.jobId !== jobId)]);
            return finalized;
          }

          if (data.status === 'FAILED' || data.status === 'CANCELLED') {
            if (activePollingRef.current) clearInterval(activePollingRef.current);
            return updated;
          }

          return updated;
        });
      } catch (err) {
        // retry on next tick
      }
    }, 600);
  };

  const cancelActiveTransfer = async (id: string, jobId?: string) => {
    if (activePollingRef.current) {
      clearInterval(activePollingRef.current);
    }
    if (jobId) {
      try {
        await fetch(`/api/upload/${jobId}/cancel`, { method: 'POST' });
      } catch (e) {}
    }
    setActiveTransfer((prev) => (prev && prev.id === id ? { ...prev, status: 'CANCELLED', errorMessage: 'Cancelled by user' } : prev));
  };

  const deleteHistoryItem = (id: string) => {
    setHistory((prev) => prev.filter((item) => item.id !== id));
  };

  const clearAllHistory = () => {
    setHistory([]);
  };

  return (
    <div className="flex h-full w-full flex-col bg-[#F8F9FA] text-[#202124] transition-colors dark:bg-[#121212] dark:text-[#E8EAED]">
      {/* Top App Bar */}
      <header className="flex h-14 shrink-0 items-center justify-between border-b border-neutral-200/80 bg-white px-4 shadow-xs dark:border-neutral-800 dark:bg-[#1E1E1E]">
        <div className="flex items-center gap-2.5">
          {currentScreen === 'settings' ? (
            <button
              onClick={() => setCurrentScreen('main')}
              className="flex h-8 w-8 items-center justify-center rounded-full text-neutral-600 hover:bg-neutral-100 dark:text-neutral-300 dark:hover:bg-neutral-800"
            >
              <ArrowLeft className="h-5 w-5" />
            </button>
          ) : (
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#1A73E8] text-white shadow-xs">
              <CloudUpload className="h-4 w-4" />
            </div>
          )}
          <div>
            <h1 className="text-sm font-bold tracking-tight">
              {currentScreen === 'settings' ? 'Settings' : 'DriveDrop'}
            </h1>
            <div className="flex items-center gap-1 text-[10px] text-neutral-400">
              <span className="inline-block h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span>Cloud Backend Connected</span>
            </div>
          </div>
        </div>

        {currentScreen === 'main' && (
          <div className="flex items-center gap-1">
            <button
              onClick={onOpenShareSheet}
              className="flex h-8 items-center gap-1 rounded-full bg-blue-50 px-2.5 text-xs font-semibold text-blue-700 hover:bg-blue-100 dark:bg-blue-950/60 dark:text-blue-300"
              title="Simulate Android Share Sheet"
            >
              <Layers className="h-3.5 w-3.5" />
              <span>Share</span>
            </button>
            <button
              onClick={() => setCurrentScreen('settings')}
              className="flex h-8 w-8 items-center justify-center rounded-full text-neutral-600 hover:bg-neutral-100 dark:text-neutral-300 dark:hover:bg-neutral-800"
              title="Settings"
            >
              <SettingsIcon className="h-5 w-5" />
            </button>
          </div>
        )}
      </header>

      {/* Main Body View */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {currentScreen === 'main' ? (
          <>
            {/* Zero Phone Data Badge */}
            <div className="flex items-center justify-between rounded-xl bg-blue-50/80 px-3 py-2 text-[11px] font-medium text-blue-900 border border-blue-100 dark:border-blue-900/40 dark:bg-blue-950/30 dark:text-blue-200">
              <div className="flex items-center gap-1.5">
                <Server className="h-3.5 w-3.5 text-blue-600 dark:text-blue-400" />
                <span>Cloud Streaming Backend</span>
              </div>
              <span className="rounded-md bg-blue-200/70 px-1.5 py-0.5 text-[10px] font-bold text-blue-900 dark:bg-blue-900 dark:text-blue-100">
                0 MB Phone Data
              </span>
            </div>

            {/* 1. Google Drive Connection Status Card */}
            <div
              className={`rounded-2xl border p-4 transition-all ${
                googleAccount?.isConnected
                  ? 'border-emerald-200/80 bg-emerald-50/50 dark:border-emerald-900/40 dark:bg-emerald-950/20'
                  : 'border-neutral-200 bg-white shadow-xs dark:border-neutral-800 dark:bg-[#1E1E1E]'
              }`}
            >
              {googleAccount?.isConnected ? (
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-900/60 dark:text-emerald-300">
                      <Cloud className="h-5 w-5" />
                    </div>
                    <div>
                      <div className="text-xs font-medium text-neutral-500 dark:text-neutral-400">
                        Google Drive Target
                      </div>
                      <div className="flex items-center gap-1.5 font-bold text-emerald-700 dark:text-emerald-400 text-sm">
                        <span>✓ Authorized</span>
                        <span className="text-xs font-normal text-neutral-500 truncate max-w-[130px]">
                          ({googleAccount.email})
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-blue-50 text-blue-600 dark:bg-blue-950 dark:text-blue-400">
                      <Cloud className="h-5 w-5" />
                    </div>
                    <div>
                      <div className="text-sm font-bold">Connect Google Drive</div>
                      <div className="text-xs text-neutral-500">
                        Authorize once for cloud direct uploads
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={onOpenOAuth}
                    className="w-full rounded-xl bg-[#1A73E8] py-2.5 text-xs font-bold tracking-wider text-white uppercase shadow-sm transition hover:bg-blue-700 active:scale-[0.98]"
                  >
                    CONNECT GOOGLE DRIVE
                  </button>
                </div>
              )}
            </div>

            {/* 2. Direct Download URL Input */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300">
                Paste direct download URL
              </label>

              <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3 text-neutral-400">
                  <LinkIcon className="h-4 w-4" />
                </div>
                <textarea
                  rows={2}
                  value={urlInput}
                  onChange={(e) => {
                    setUrlInput(e.target.value);
                    if (urlError) setUrlError(null);
                  }}
                  placeholder="Paste direct download URL (e.g. https://.../video.mp4)"
                  className={`w-full rounded-xl border bg-white p-2.5 pl-9 pr-8 text-xs leading-relaxed focus:outline-hidden dark:bg-[#1E1E1E] ${
                    urlError
                      ? 'border-red-500 focus:border-red-500'
                      : 'border-neutral-300 focus:border-[#1A73E8] dark:border-neutral-700'
                  }`}
                />
                {urlInput && (
                  <button
                    onClick={() => setUrlInput('')}
                    className="absolute top-2.5 right-2.5 text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-200"
                  >
                    <X className="h-4 w-4" />
                  </button>
                )}
              </div>

              {urlError && (
                <div className="flex items-center gap-1 text-[11px] text-red-600 dark:text-red-400">
                  <AlertCircle className="h-3.5 w-3.5 shrink-0" />
                  <span>{urlError}</span>
                </div>
              )}

              {/* Sample URL Quick Chips */}
              <div className="flex flex-wrap items-center gap-1.5 pt-1">
                <span className="text-[10px] font-semibold text-neutral-400">Try sample:</span>
                {SAMPLE_URLS.slice(0, 3).map((sample) => (
                  <button
                    key={sample.url}
                    type="button"
                    onClick={() => {
                      setUrlInput(sample.url);
                      setUrlError(null);
                    }}
                    className="rounded-lg border border-neutral-200 bg-white px-2 py-0.5 text-[10px] font-medium text-neutral-600 transition hover:border-blue-400 hover:text-blue-600 dark:border-neutral-800 dark:bg-[#1E1E1E] dark:text-neutral-300"
                  >
                    {sample.category}
                  </button>
                ))}
              </div>
            </div>

            {/* 3. UPLOAD TO DRIVE Button */}
            <button
              type="button"
              disabled={isStarting || (activeTransfer !== null && activeTransfer.status !== 'UPLOAD_COMPLETED' && activeTransfer.status !== 'FAILED' && activeTransfer.status !== 'CANCELLED')}
              onClick={() => startTransferProcess(urlInput)}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#1A73E8] py-3 text-xs font-bold tracking-wider text-white uppercase shadow-md transition hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-50 active:scale-[0.99]"
            >
              {isStarting ? (
                <>
                  <RefreshCw className="h-4 w-4 animate-spin" />
                  <span>Submitting to Cloud Backend…</span>
                </>
              ) : (
                <>
                  <CloudUpload className="h-4 w-4" />
                  <span>UPLOAD TO DRIVE</span>
                </>
              )}
            </button>

            {/* 4. Current Transfer Progress Card (Represents CLOUD Progress) */}
            {activeTransfer && activeTransfer.status !== 'IDLE' && (
              <div className="rounded-2xl border border-neutral-200 bg-white p-4 shadow-sm space-y-3 dark:border-neutral-800 dark:bg-[#1E1E1E]">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2.5">
                    <div
                      className={`flex h-8 w-8 items-center justify-center rounded-full ${
                        activeTransfer.status === 'UPLOAD_COMPLETED'
                          ? 'bg-emerald-100 text-emerald-600 dark:bg-emerald-950 dark:text-emerald-400'
                          : activeTransfer.status === 'FAILED'
                          ? 'bg-red-100 text-red-600'
                          : 'bg-blue-100 text-[#1A73E8] dark:bg-blue-950 dark:text-blue-400'
                      }`}
                    >
                      {activeTransfer.status === 'UPLOAD_COMPLETED' ? (
                        <CheckCircle className="h-4 w-4" />
                      ) : activeTransfer.status === 'FAILED' ? (
                        <AlertCircle className="h-4 w-4" />
                      ) : (
                        <Server className="h-4 w-4 animate-pulse" />
                      )}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">
                          Cloud Transfer Job
                        </span>
                        {activeTransfer.jobId && (
                          <span className="font-mono text-[9px] text-neutral-400 bg-neutral-100 dark:bg-neutral-800 px-1 rounded">
                            {activeTransfer.jobId.slice(0, 10)}
                          </span>
                        )}
                      </div>
                      <div className="max-w-[170px] truncate text-xs font-bold text-neutral-900 dark:text-neutral-100">
                        {activeTransfer.fileName}
                      </div>
                    </div>
                  </div>

                  {activeTransfer.status === 'DOWNLOADING' || activeTransfer.status === 'UPLOADING' || activeTransfer.status === 'QUEUED' ? (
                    <button
                      onClick={() => cancelActiveTransfer(activeTransfer.id, activeTransfer.jobId)}
                      className="rounded-lg border border-neutral-200 px-2 py-1 text-[10px] font-semibold text-neutral-600 hover:bg-neutral-100 dark:border-neutral-700 dark:text-neutral-300"
                    >
                      Cancel
                    </button>
                  ) : null}
                </div>

                {/* Error Notice if any */}
                {activeTransfer.errorMessage && (
                  <div className="rounded-xl bg-red-50 p-2.5 text-xs text-red-700 border border-red-200 dark:bg-red-950/40 dark:border-red-900/40 dark:text-red-300">
                    <div className="font-semibold">Transfer Error:</div>
                    <div className="text-[11px] mt-0.5">{activeTransfer.errorMessage}</div>
                  </div>
                )}

                {/* Cloud Progress Stages */}
                <div className="space-y-3 pt-1">
                  {/* Stage 1: Cloud Download from Source */}
                  <div>
                    <div className="flex justify-between text-xs font-medium">
                      <span
                        className={
                          activeTransfer.status === 'DOWNLOADING'
                            ? 'font-bold text-[#1A73E8]'
                            : activeTransfer.status === 'QUEUED'
                            ? 'text-neutral-500'
                            : 'text-neutral-600 dark:text-neutral-400'
                        }
                      >
                        {activeTransfer.status === 'QUEUED'
                          ? 'Cloud status: Queued on worker…'
                          : activeTransfer.status === 'DOWNLOADING'
                          ? 'Cloud status: Downloading from source…'
                          : '✓ Cloud stream received'}
                      </span>
                      <span className="font-mono text-xs font-bold">
                        {activeTransfer.downloadProgress}%
                      </span>
                    </div>
                    <div className="mt-1 h-2 w-full overflow-hidden rounded-full bg-neutral-100 dark:bg-neutral-800">
                      <div
                        className="h-full bg-[#1A73E8] transition-all duration-200"
                        style={{ width: `${activeTransfer.downloadProgress}%` }}
                      />
                    </div>
                  </div>

                  {/* Stage 2: Cloud Upload to Google Drive */}
                  {(activeTransfer.status === 'UPLOADING' ||
                    activeTransfer.status === 'UPLOAD_COMPLETED' ||
                    activeTransfer.uploadProgress > 0) && (
                    <div>
                      <div className="flex justify-between text-xs font-medium">
                        <span
                          className={
                            activeTransfer.status === 'UPLOADING'
                              ? 'font-bold text-[#1A73E8]'
                              : 'font-bold text-emerald-600 dark:text-emerald-400'
                          }
                        >
                          {activeTransfer.status === 'UPLOADING'
                            ? 'Cloud status: Uploading to Google Drive…'
                            : '✓ Upload completed'}
                        </span>
                        <span className="font-mono text-xs font-bold">
                          {activeTransfer.uploadProgress}%
                        </span>
                      </div>
                      <div className="mt-1 h-2 w-full overflow-hidden rounded-full bg-neutral-100 dark:bg-neutral-800">
                        <div
                          className={`h-full transition-all duration-200 ${
                            activeTransfer.status === 'UPLOAD_COMPLETED'
                              ? 'bg-emerald-600'
                              : 'bg-[#1A73E8]'
                          }`}
                          style={{ width: `${activeTransfer.uploadProgress}%` }}
                        />
                      </div>
                    </div>
                  )}

                  {/* Stage 3: Completed Target Display */}
                  {activeTransfer.status === 'UPLOAD_COMPLETED' && (
                    <div className="rounded-xl bg-emerald-50 p-3 text-xs text-emerald-900 dark:bg-emerald-950/40 dark:text-emerald-200 space-y-1">
                      <div className="font-bold flex items-center gap-1">
                        <CheckCircle className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                        <span>✓ Upload completed</span>
                      </div>
                      <div className="text-[11px] text-emerald-800 dark:text-emerald-300">
                        <strong>File:</strong> {activeTransfer.fileName}
                      </div>
                      <div className="text-[11px] text-emerald-800 dark:text-emerald-300">
                        <strong>Google Drive:</strong> {activeTransfer.driveFolderPath}/
                        {activeTransfer.fileName}
                      </div>
                      <div className="pt-1 text-[10px] text-emerald-700/80 dark:text-emerald-400 flex items-center gap-1 font-mono">
                        <Zap className="h-3 w-3" />
                        <span>0 MB phone data used • 100% transferred via cloud</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* 5. Recent Cloud Upload History */}
            <div className="space-y-2 pt-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-neutral-700 dark:text-neutral-300">
                  Recent Cloud Transfers
                </span>
                {history.length > 0 && (
                  <button
                    onClick={clearAllHistory}
                    className="text-[10px] font-semibold text-neutral-400 hover:text-red-500"
                  >
                    Clear History
                  </button>
                )}
              </div>

              {history.length === 0 ? (
                <div className="rounded-xl border border-dashed border-neutral-200 p-6 text-center text-xs text-neutral-400 dark:border-neutral-800">
                  No previous transfer records.
                </div>
              ) : (
                <div className="space-y-2">
                  {history.map((item) => (
                    <div
                      key={item.id}
                      className="flex items-center justify-between rounded-xl border border-neutral-200 bg-white p-3 shadow-2xs dark:border-neutral-800 dark:bg-[#1E1E1E]"
                    >
                      <div className="flex items-center gap-2.5 overflow-hidden">
                        <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-950 dark:text-emerald-400">
                          <CheckCircle className="h-4 w-4" />
                        </div>
                        <div className="overflow-hidden">
                          <div className="truncate text-xs font-bold text-neutral-900 dark:text-neutral-100">
                            {item.fileName}
                          </div>
                          <div className="text-[10px] text-neutral-400">
                            {new Date(item.completedAtTimestamp || item.createdAtTimestamp).toLocaleTimeString([], {
                              hour: '2-digit',
                              minute: '2-digit',
                            })}{' '}
                            • {item.driveFolderPath} • <span className="text-emerald-600 dark:text-emerald-400 font-medium">0MB Mobile Data</span>
                          </div>
                        </div>
                      </div>

                      <button
                        onClick={() => deleteHistoryItem(item.id)}
                        className="p-1 text-neutral-400 hover:text-red-500"
                        title="Delete record"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </>
        ) : (
          /* Settings Screen */
          <div className="space-y-4">
            {/* Account Card */}
            <div className="rounded-2xl border border-neutral-200 bg-white p-4 shadow-xs dark:border-neutral-800 dark:bg-[#1E1E1E] space-y-3">
              <h3 className="text-xs font-bold text-neutral-500 uppercase">Google Drive Account</h3>
              {googleAccount?.isConnected ? (
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={googleAccount.photoUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80'}
                      alt=""
                      className="h-10 w-10 rounded-full object-cover"
                    />
                    <div>
                      <div className="text-sm font-bold">{googleAccount.displayName}</div>
                      <div className="text-xs text-neutral-500">{googleAccount.email}</div>
                    </div>
                  </div>
                  <button
                    onClick={onDisconnectDrive}
                    className="flex w-full items-center justify-center gap-1.5 rounded-xl border border-red-200 py-2 text-xs font-bold text-red-600 hover:bg-red-50 dark:border-red-900/40 dark:hover:bg-red-950/40"
                  >
                    <LogOut className="h-3.5 w-3.5" />
                    <span>Disconnect Google Drive</span>
                  </button>
                </div>
              ) : (
                <div className="space-y-2">
                  <p className="text-xs text-neutral-500">No account connected.</p>
                  <button
                    onClick={onOpenOAuth}
                    className="w-full rounded-xl bg-[#1A73E8] py-2 text-xs font-bold text-white"
                  >
                    Connect Account
                  </button>
                </div>
              )}
            </div>

            {/* Folder Setting */}
            <div className="rounded-2xl border border-neutral-200 bg-white p-4 shadow-xs dark:border-neutral-800 dark:bg-[#1E1E1E] space-y-2">
              <div className="flex items-center gap-2">
                <Folder className="h-4 w-4 text-[#1A73E8]" />
                <h3 className="text-xs font-bold text-neutral-500 uppercase">Default Google Drive Folder</h3>
              </div>
              <input
                type="text"
                value={folderName}
                onChange={(e) => setFolderName(e.target.value)}
                className="w-full rounded-xl border border-neutral-300 p-2.5 text-xs focus:border-[#1A73E8] focus:outline-hidden dark:border-neutral-700 dark:bg-neutral-800"
              />
              <p className="text-[11px] text-neutral-400">
                DriveDrop will create this folder in your Google Drive root if it doesn't already exist.
              </p>
            </div>

            {/* Cloud Backend Architecture Card */}
            <div className="rounded-2xl border border-neutral-200 bg-white p-4 shadow-xs dark:border-neutral-800 dark:bg-[#1E1E1E] space-y-2">
              <div className="flex items-center gap-2">
                <Server className="h-4 w-4 text-blue-600" />
                <h3 className="text-xs font-bold text-neutral-500 uppercase">Cloud Architecture (Option 2)</h3>
              </div>
              <p className="text-[11px] leading-relaxed text-neutral-500">
                • <strong>Direct URL Transfer:</strong> URL is sent to the Cloud Backend (`/api/upload`).<br />
                • <strong>Zero Phone Data:</strong> Large files stream directly into Google Drive in the cloud.<br />
                • <strong>Resumable Uploads:</strong> Uses Google Drive v3 Resumable Upload protocol.<br />
                • <strong>Background Survival:</strong> Transfers continue uninterrupted even if the Android app is closed.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
