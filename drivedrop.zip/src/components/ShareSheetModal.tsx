import React from 'react';
import { SAMPLE_URLS } from '../data/sampleUrls';
import { CloudUpload, Share2, X, ExternalLink } from 'lucide-react';

interface ShareSheetModalProps {
  isOpen: boolean;
  onClose: () => void;
  onShareToDriveDrop: (url: string) => void;
}

export const ShareSheetModal: React.FC<ShareSheetModalProps> = ({
  isOpen,
  onClose,
  onShareToDriveDrop,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-xs sm:items-center sm:p-4">
      <div className="w-full max-w-sm rounded-t-3xl bg-white p-5 shadow-2xl transition-all sm:rounded-3xl dark:bg-neutral-900 dark:text-white">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Share2 className="h-5 w-5 text-neutral-500" />
            <h3 className="text-base font-semibold">Android Share Sheet</h3>
          </div>
          <button
            onClick={onClose}
            className="rounded-full p-1 text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <p className="mb-3 text-xs text-neutral-500 dark:text-neutral-400">
          Simulate sharing a direct URL from Chrome, Telegram, or another app directly into DriveDrop via <code className="text-blue-600 dark:text-blue-400">Intent.ACTION_SEND</code>:
        </p>

        <div className="max-h-64 space-y-2 overflow-y-auto pr-1">
          {SAMPLE_URLS.map((sample) => (
            <button
              key={sample.url}
              type="button"
              onClick={() => {
                onShareToDriveDrop(sample.url);
                onClose();
              }}
              className="flex w-full items-center justify-between rounded-xl border border-neutral-200 p-2.5 text-left hover:border-blue-400 hover:bg-blue-50/50 dark:border-neutral-800 dark:hover:bg-blue-950/30"
            >
              <div className="overflow-hidden pr-2">
                <div className="truncate text-xs font-semibold text-neutral-800 dark:text-neutral-200">
                  {sample.name}
                </div>
                <div className="truncate text-[10px] text-neutral-500">{sample.url}</div>
              </div>
              <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-blue-600 text-white shadow-xs">
                <CloudUpload className="h-3.5 w-3.5" />
              </div>
            </button>
          ))}
        </div>

        <div className="mt-4 border-t border-neutral-100 pt-3 dark:border-neutral-800">
          <button
            type="button"
            onClick={onClose}
            className="w-full rounded-xl bg-neutral-100 py-2 text-xs font-semibold text-neutral-700 hover:bg-neutral-200 dark:bg-neutral-800 dark:text-neutral-300"
          >
            Close Sheet
          </button>
        </div>
      </div>
    </div>
  );
};
