import React, { useState } from 'react';
import { NotificationDrawer } from './NotificationDrawer';
import { TransferRecord } from '../types';
import { Wifi, Battery, Signal, Volume2 } from 'lucide-react';

interface AndroidDeviceFrameProps {
  children: React.ReactNode;
  activeTransfer: TransferRecord | null;
  onCancelTransfer: () => void;
}

export const AndroidDeviceFrame: React.FC<AndroidDeviceFrameProps> = ({
  children,
  activeTransfer,
  onCancelTransfer,
}) => {
  const [drawerOpen, setDrawerOpen] = useState(false);

  return (
    <div className="relative mx-auto flex h-[740px] w-[360px] flex-col overflow-hidden rounded-[42px] border-[10px] border-neutral-900 bg-black shadow-2xl ring-1 ring-white/20 sm:w-[380px]">
      {/* Front Camera Punch-hole */}
      <div className="absolute top-3 left-1/2 z-40 h-4 w-4 -translate-x-1/2 rounded-full bg-neutral-950 ring-2 ring-neutral-800" />

      {/* Android System Status Bar */}
      <div className="relative z-30 flex h-8 shrink-0 items-center justify-between px-6 pt-1 text-[11px] font-medium text-neutral-800 dark:text-neutral-200">
        <span className="font-mono">9:41</span>
        <div className="flex items-center gap-2">
          <Signal className="h-3 w-3" />
          <Wifi className="h-3 w-3" />
          <Battery className="h-3.5 w-3.5" />
        </div>
      </div>

      {/* Persistent Notification Pull-down Drawer */}
      <NotificationDrawer
        isOpen={drawerOpen}
        onToggle={() => setDrawerOpen(!drawerOpen)}
        activeTransfer={activeTransfer}
        onCancelTransfer={onCancelTransfer}
      />

      {/* Main Screen Content */}
      <div className="relative flex-1 overflow-hidden bg-[#F8F9FA] dark:bg-[#121212]">
        {children}
      </div>

      {/* Android Gesture Navigation Bar */}
      <div className="flex h-5 shrink-0 items-center justify-center bg-white dark:bg-[#1E1E1E]">
        <div className="h-1 w-32 rounded-full bg-neutral-400 dark:bg-neutral-600" />
      </div>
    </div>
  );
};
