export type TransferStatus =
  | 'IDLE'
  | 'QUEUED'
  | 'VALIDATING'
  | 'DOWNLOADING'
  | 'DOWNLOAD_COMPLETE'
  | 'AUTHENTICATING'
  | 'UPLOADING'
  | 'UPLOAD_COMPLETED'
  | 'COMPLETED'
  | 'FAILED'
  | 'CANCELLED';

export interface TransferRecord {
  id: string;
  jobId?: string;
  directUrl: string;
  fileName: string;
  fileSizeBytes: number;
  mimeType: string;
  status: TransferStatus;
  downloadProgress: number;
  uploadProgress: number;
  downloadSpeedMBs?: number;
  uploadSpeedMBs?: number;
  errorMessage?: string;
  driveFileId?: string;
  driveFolderPath: string;
  createdAtTimestamp: number;
  completedAtTimestamp?: number;
  phoneDataUsedBytes?: number; // 0 for Cloud architecture
  cloudTransferredBytes?: number;
}

export interface CloudJob {
  jobId: string;
  url: string;
  fileName: string;
  fileSizeBytes: number;
  mimeType: string;
  status: TransferStatus;
  progress: number;
  downloadProgress: number;
  uploadProgress: number;
  downloadSpeedMBs: number;
  uploadSpeedMBs: number;
  message: string;
  driveFileId?: string;
  driveFolderPath: string;
  error?: string;
  createdAt: number;
  updatedAt: number;
  completedAt?: number;
}

export interface UploadRequest {
  url: string;
  folderName?: string;
  customFileName?: string;
  googleAccessToken?: string;
}

export interface UploadResponse {
  jobId: string;
  status: string;
  fileName: string;
  message: string;
  createdAt: number;
}

export interface JobStatusResponse {
  jobId: string;
  status: TransferStatus;
  progress: number;
  downloadProgress: number;
  uploadProgress: number;
  fileName: string;
  fileSizeBytes: number;
  mimeType: string;
  message: string;
  driveFileId?: string;
  driveFolderPath: string;
  error?: string;
  createdAt: number;
  completedAt?: number;
}

export interface GoogleAccount {
  email: string;
  displayName: string;
  photoUrl?: string;
  isConnected: boolean;
  lastConnectedTime: number;
  accessToken?: string;
}

export interface SampleUrl {
  name: string;
  url: string;
  category: string;
  estimatedSize: string;
}

