import { Router, Request, Response } from 'express';
import {
  createUploadJob,
  getJob,
  getAllJobs,
  cancelJob,
  isValidHttpUrl,
} from './cloudWorker';

export const apiRouter = Router();

/**
 * Health check & cloud worker status
 */
apiRouter.get('/health', (req: Request, res: Response) => {
  const jobs = getAllJobs();
  const activeCount = jobs.filter(
    (j) => j.status === 'DOWNLOADING' || j.status === 'UPLOADING' || j.status === 'QUEUED'
  ).length;

  res.json({
    status: 'ok',
    service: 'DriveDrop-Cloud-Worker',
    platform: 'Google Cloud Run',
    serverTime: new Date().toISOString(),
    activeJobs: activeCount,
    totalJobsProcessed: jobs.length,
    features: {
      zeroDeviceBandwidth: true,
      streamingPipeline: true,
      driveResumableUpload: true,
    },
  });
});

/**
 * POST /api/upload
 * Initiates a cloud-side file transfer
 */
apiRouter.post('/upload', (req: Request, res: Response) => {
  try {
    const { url, folderName, customFileName, googleAccessToken } = req.body || {};

    if (!url || typeof url !== 'string') {
      res.status(400).json({
        error: 'Missing required field: "url"',
        message: 'A valid direct HTTP/HTTPS URL is required.',
      });
      return;
    }

    if (!isValidHttpUrl(url)) {
      res.status(400).json({
        error: 'Invalid URL',
        message: 'The URL must be a valid public HTTP or HTTPS direct download link.',
      });
      return;
    }

    // Optional auth token from header or body
    const authHeader = req.headers.authorization;
    const token =
      googleAccessToken ||
      (authHeader?.startsWith('Bearer ') ? authHeader.substring(7) : undefined);

    const job = createUploadJob(url.trim(), {
      folderName: folderName?.trim() || 'DriveDrop',
      customFileName: customFileName?.trim(),
      googleAccessToken: token,
    });

    res.status(202).json({
      jobId: job.jobId,
      status: job.status.toLowerCase(),
      fileName: job.fileName,
      message: job.message,
      createdAt: job.createdAt,
    });
  } catch (err: any) {
    res.status(500).json({
      error: 'Failed to create upload job',
      message: err.message || 'Internal server error',
    });
  }
});

/**
 * GET /api/upload/:jobId/status
 * Retrieves status, download & upload progress, and Drive result
 */
apiRouter.get('/upload/:jobId/status', (req: Request, res: Response) => {
  const { jobId } = req.params;
  const job = getJob(jobId);

  if (!job) {
    res.status(404).json({
      error: 'Job not found',
      message: `No cloud transfer job found with ID: ${jobId}`,
    });
    return;
  }

  res.json({
    jobId: job.jobId,
    status: job.status,
    progress: job.progress,
    downloadProgress: job.downloadProgress,
    uploadProgress: job.uploadProgress,
    downloadSpeedMBs: job.downloadSpeedMBs,
    uploadSpeedMBs: job.uploadSpeedMBs,
    fileName: job.fileName,
    fileSizeBytes: job.fileSizeBytes,
    mimeType: job.mimeType,
    message: job.message,
    driveFileId: job.driveFileId,
    driveFolderPath: job.driveFolderPath,
    error: job.error,
    createdAt: job.createdAt,
    completedAt: job.completedAt,
  });
});

/**
 * POST /api/upload/:jobId/cancel
 * Cancels an ongoing cloud stream transfer
 */
apiRouter.post('/upload/:jobId/cancel', (req: Request, res: Response) => {
  const { jobId } = req.params;
  const cancelled = cancelJob(jobId);

  if (!cancelled) {
    res.status(400).json({
      error: 'Cannot cancel job',
      message: `Job ${jobId} not found or is already completed/failed.`,
    });
    return;
  }

  const job = getJob(jobId);
  res.json({
    jobId,
    status: job?.status || 'CANCELLED',
    message: 'Job cancelled successfully on cloud backend.',
  });
});

/**
 * GET /api/jobs
 * Retrieves list of all jobs for synchronization
 */
apiRouter.get('/jobs', (req: Request, res: Response) => {
  const jobs = getAllJobs();
  res.json({
    jobs,
    count: jobs.length,
  });
});
