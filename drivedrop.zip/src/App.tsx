import React, { useState, useEffect, useRef } from 'react';
import { OAuthConnectModal } from './components/OAuthConnectModal';
import { SetupGuideModal } from './components/SetupGuideModal';
import { GoogleAccount, TransferRecord, JobStatusResponse } from './types';
import { SAMPLE_URLS } from './data/sampleUrls';
import {
  CloudUpload,
  Cloud,
  CheckCircle,
  AlertCircle,
  ExternalLink,
  Trash2,
  X,
  Sparkles,
  Server,
  Zap,
  Folder,
  ArrowRight,
  Loader2,
  RefreshCw,
  LogOut,
  HelpCircle,
  FileText,
  Video,
  Image as ImageIcon,
  Archive,
} from 'lucide-react';

export function App() {
  const [isOAuthOpen, setIsOAuthOpen] = useState(false);
  const [isSetupGuideOpen, setIsSetupGuideOpen] = useState(false);
  const [urlInput, setUrlInput] = useState('');
  const [folderName, setFolderName] = useState('DriveDrop');
  const [urlError, setUrlError] = useState<string | null>(null);
  const [isStarting, setIsStarting] = useState(false);
  const [activeTransfer, setActiveTransfer] = useState<TransferRecord | null>(null);
  const activePollingRef = useRef<number | null>(null);

  // Google Account state
  const [googleAccount, setGoogleAccount] = useState<GoogleAccount | null>(() => {
    const saved = localStorage.getItem('drivedrop_user_account');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return null;
      }
    }
    return {
      email: 'alex.developer@gmail.com',
      displayName: 'Alex Developer',
      photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80',
      isConnected: true,
      lastConnectedTime: Date.now(),
      accessToken: 'sim_' + Date.now(),
    };
  });

  // Transfer history
  const [history, setHistory] = useState<TransferRecord[]>(() => {
    const saved = localStorage.getItem('drivedrop_cloud_history');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return [];
      }
    }
    return [
      {
        id: 'seed-1',
        jobId: 'job_sample_01',
        directUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
        fileName: 'BigBuckBunny.mp4',
        fileSizeBytes: 158000000,
        mimeType: 'video/mp4',
        status: 'UPLOAD_COMPLETED',
        downloadProgress: 100,
        uploadProgress: 100,
        driveFileId: '1AbC9dE_FghIjKlMnOpQrStUvWxYz1234',
        driveFolderPath: 'DriveDrop',
        createdAtTimestamp: Date.now() - 3600000 * 2,
        completedAtTimestamp: Date.now() - 3600000 * 2 + 12000,
        phoneDataUsedBytes: 0,
        cloudTransferredBytes: 158000000,
      },
    ];
  });

  // Persist account
  useEffect(() => {
    if (googleAccount) {
      localStorage.setItem('drivedrop_user_account', JSON.stringify(googleAccount));
    } else {
      localStorage.removeItem('drivedrop_user_account');
    }
  }, [googleAccount]);

  // Persist history
  useEffect(() => {
    localStorage.setItem('drivedrop_cloud_history', JSON.stringify(history));
  }, [history]);

  // Check active jobs on mount
  useEffect(() => {
    const checkActiveJobs = async () => {
      try {
        const res = await fetch('/api/jobs');
        if (res.ok) {
          const data = await res.json();
          const running = data.jobs?.find(
            (j: any) => j.status === 'DOWNLOADING' || j.status === 'UPLOADING' || j.status === 'QUEUED'
          );
          if (running && !activeTransfer) {
            pollJobStatus(running.jobId, {
              id: 'tx-' + running.jobId,
              jobId: running.jobId,
              directUrl: running.url,
              fileName: running.fileName,
              fileSizeBytes: running.fileSizeBytes || 0,
              mimeType: running.mimeType || 'application/octet-stream',
              status: running.status,
              downloadProgress: running.downloadProgress || 0,
              uploadProgress: running.uploadProgress || 0,
              driveFolderPath: running.driveFolderPath || 'DriveDrop',
              createdAtTimestamp: running.createdAt || Date.now(),
              phoneDataUsedBytes: 0,
              cloudTransferredBytes: 0,
            });
          }
        }
      } catch (e) {}
    };
    checkActiveJobs();
  }, []);

  const handleStartTransfer = async (urlToUse?: string) => {
    const targetUrl = (urlToUse || urlInput).trim();
    if (!targetUrl) {
      setUrlError('Please enter a valid direct download URL.');
      return;
    }
    if (!targetUrl.startsWith('http://') && !targetUrl.startsWith('https://')) {
      setUrlError('URL must start with http:// or https://');
      return;
    }

    setUrlError(null);
    setIsStarting(true);

    try {
      const res = await fetch('/api/upload', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(googleAccount?.accessToken ? { Authorization: `Bearer ${googleAccount.accessToken}` } : {}),
        },
        body: JSON.stringify({
          url: targetUrl,
          folderName: folderName.trim() || 'DriveDrop',
          googleAccessToken: googleAccount?.accessToken,
        }),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.message || `Server error (${res.status})`);
      }

      const { jobId, fileName } = await res.json();
      const initialRecord: TransferRecord = {
        id: 'tx-' + jobId,
        jobId,
        directUrl: targetUrl,
        fileName: fileName || 'file',
        fileSizeBytes: 0,
        mimeType: 'application/octet-stream',
        status: 'DOWNLOADING',
        downloadProgress: 0,
        uploadProgress: 0,
        driveFolderPath: folderName.trim() || 'DriveDrop',
        createdAtTimestamp: Date.now(),
        phoneDataUsedBytes: 0,
        cloudTransferredBytes: 0,
      };

      setActiveTransfer(initialRecord);
      setUrlInput('');
      setIsStarting(false);

      pollJobStatus(jobId, initialRecord);
    } catch (err: any) {
      setIsStarting(false);
      setUrlError(err.message || 'Failed to start cloud transfer');
    }
  };

  const pollJobStatus = (jobId: string, baseRecord: TransferRecord) => {
    if (activePollingRef.current) {
      clearInterval(activePollingRef.current);
    }

    activePollingRef.current = window.setInterval(async () => {
      try {
        const res = await fetch(`/api/upload/${jobId}/status`);
        if (!res.ok) throw new Error(`Status error (${res.status})`);

        const data: JobStatusResponse = await res.json();

        setActiveTransfer((prev) => {
          if (!prev) return prev;

          const updated: TransferRecord = {
            ...prev,
            status: data.status,
            fileName: data.fileName || prev.fileName,
            fileSizeBytes: data.fileSizeBytes || prev.fileSizeBytes,
            mimeType: data.mimeType || prev.mimeType,
            downloadProgress: data.downloadProgress,
            uploadProgress: data.uploadProgress,
            errorMessage: data.error,
            driveFileId: data.driveFileId,
            phoneDataUsedBytes: 0,
            cloudTransferredBytes: data.fileSizeBytes || 1024 * 1024 * 50,
          };

          if (data.status === 'UPLOAD_COMPLETED' || data.status === 'COMPLETED') {
            if (activePollingRef.current) clearInterval(activePollingRef.current);
            const finalized: TransferRecord = {
              ...updated,
              status: 'UPLOAD_COMPLETED',
              completedAtTimestamp: data.completedAt || Date.now(),
            };
            setHistory((old) => [finalized, ...old.filter((h) => h.id !== finalized.id && h.jobId !== jobId)]);
            return finalized;
          }

          if (data.status === 'FAILED' || data.status === 'CANCELLED') {
            if (activePollingRef.current) clearInterval(activePollingRef.current);
            return updated;
          }

          return updated;
        });
      } catch (e) {}
    }, 600);
  };

  const handleCancelTransfer = async () => {
    if (activePollingRef.current) {
      clearInterval(activePollingRef.current);
    }
    if (activeTransfer?.jobId) {
      try {
        await fetch(`/api/upload/${activeTransfer.jobId}/cancel`, { method: 'POST' });
      } catch (e) {}
    }
    setActiveTransfer((prev) => (prev ? { ...prev, status: 'CANCELLED', errorMessage: 'Cancelled by user' } : null));
  };

  const getFileIcon = (fileName: string, mime?: string) => {
    const ext = fileName.split('.').pop()?.toLowerCase() || '';
    if (['mp4', 'mkv', 'avi', 'mov', 'webm'].includes(ext) || mime?.startsWith('video/')) {
      return <Video className="h-5 w-5 text-purple-500" />;
    }
    if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'].includes(ext) || mime?.startsWith('image/')) {
      return <ImageIcon className="h-5 w-5 text-blue-500" />;
    }
    if (['zip', 'rar', '7z', 'tar', 'gz', 'iso'].includes(ext)) {
      return <Archive className="h-5 w-5 text-amber-500" />;
    }
    return <FileText className="h-5 w-5 text-emerald-500" />;
  };

  const formatBytes = (bytes: number) => {
    if (!bytes || bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  return (
    <div className="min-h-screen bg-neutral-50 text-neutral-900 antialiased dark:bg-neutral-950 dark:text-neutral-100 flex flex-col">
      {/* Clean Top Navigation Bar */}
      <header className="sticky top-0 z-30 border-b border-neutral-200/80 bg-white/90 px-4 py-3 backdrop-blur-md dark:border-neutral-800 dark:bg-neutral-900/90">
        <div className="mx-auto flex max-w-4xl items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-600 text-white shadow-sm">
              <CloudUpload className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-bold tracking-tight">DriveDrop</h1>
                <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-semibold text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                  0 MB Phone Data
                </span>
              </div>
              <p className="text-xs text-neutral-500 dark:text-neutral-400">
                Direct URL to Google Drive Streaming
              </p>
            </div>
          </div>

          {/* Account & Help Actions */}
          <div className="flex items-center gap-2">
            {googleAccount?.isConnected ? (
              <button
                type="button"
                onClick={() => setIsOAuthOpen(true)}
                className="flex items-center gap-2 rounded-xl border border-neutral-200 bg-white px-3 py-1.5 text-xs font-medium text-neutral-700 shadow-2xs hover:bg-neutral-50 dark:border-neutral-800 dark:bg-neutral-800 dark:text-neutral-200 dark:hover:bg-neutral-700"
              >
                {googleAccount.photoUrl ? (
                  <img
                    src={googleAccount.photoUrl}
                    alt={googleAccount.displayName}
                    className="h-5 w-5 rounded-full object-cover"
                  />
                ) : (
                  <div className="flex h-5 w-5 items-center justify-center rounded-full bg-blue-100 text-blue-700 text-[10px] font-bold">
                    {googleAccount.email.charAt(0).toUpperCase()}
                  </div>
                )}
                <span className="hidden sm:inline font-semibold">{googleAccount.displayName || googleAccount.email}</span>
                <span className="rounded-full bg-emerald-500 h-2 w-2" />
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setIsOAuthOpen(true)}
                className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-3.5 py-1.5 text-xs font-semibold text-white shadow-xs hover:bg-blue-700"
              >
                <Cloud className="h-4 w-4" />
                <span>Connect Google Drive</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => setIsSetupGuideOpen(true)}
              className="flex h-8 w-8 items-center justify-center rounded-xl text-neutral-500 hover:bg-neutral-100 dark:text-neutral-400 dark:hover:bg-neutral-800"
              title="Setup Guide"
            >
              <HelpCircle className="h-4 w-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Streamlined Interface */}
      <main className="mx-auto w-full max-w-4xl flex-1 px-4 py-8 space-y-6">
        {/* Main Input Transfer Card */}
        <section className="rounded-2xl border border-neutral-200 bg-white p-6 shadow-sm dark:border-neutral-800 dark:bg-neutral-900">
          <div className="space-y-4">
            <div>
              <label htmlFor="url-input" className="block text-xs font-bold uppercase tracking-wider text-neutral-500 dark:text-neutral-400">
                Direct File Download URL
              </label>
              <div className="mt-2 flex rounded-xl border border-neutral-300 bg-neutral-50/50 p-1.5 focus-within:border-blue-500 focus-within:bg-white focus-within:ring-2 focus-within:ring-blue-500/20 dark:border-neutral-700 dark:bg-neutral-800/50 dark:focus-within:bg-neutral-800">
                <input
                  id="url-input"
                  type="url"
                  placeholder="https://example.com/file.zip or video.mp4"
                  value={urlInput}
                  onChange={(e) => {
                    setUrlInput(e.target.value);
                    setUrlError(null);
                  }}
                  onKeyDown={(e) => e.key === 'Enter' && handleStartTransfer()}
                  className="flex-1 bg-transparent px-3 py-2 text-sm text-neutral-900 placeholder-neutral-400 focus:outline-hidden dark:text-white"
                />
                {urlInput && (
                  <button
                    type="button"
                    onClick={() => setUrlInput('')}
                    className="p-2 text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-200"
                  >
                    <X className="h-4 w-4" />
                  </button>
                )}
              </div>
              {urlError && <p className="mt-1.5 text-xs text-red-500 font-medium">{urlError}</p>}
            </div>

            {/* Folder & Action Controls */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2">
              <div className="flex items-center gap-2">
                <Folder className="h-4 w-4 text-neutral-400" />
                <span className="text-xs text-neutral-500">Save inside:</span>
                <input
                  type="text"
                  value={folderName}
                  onChange={(e) => setFolderName(e.target.value)}
                  className="w-32 rounded-lg border border-neutral-300 bg-white px-2.5 py-1 text-xs font-semibold text-neutral-800 focus:border-blue-500 focus:outline-hidden dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-200"
                  placeholder="DriveDrop"
                />
              </div>

              <button
                type="button"
                onClick={() => handleStartTransfer()}
                disabled={isStarting || !urlInput.trim()}
                className="flex items-center justify-center gap-2 rounded-xl bg-blue-600 px-6 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isStarting ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>Connecting...</span>
                  </>
                ) : (
                  <>
                    <CloudUpload className="h-4 w-4" />
                    <span>Transfer to Google Drive</span>
                  </>
                )}
              </button>
            </div>

            {/* Quick Test Samples */}
            <div className="pt-2 border-t border-neutral-100 dark:border-neutral-800">
              <div className="flex items-center gap-2 mb-2">
                <Sparkles className="h-3.5 w-3.5 text-amber-500" />
                <span className="text-xs font-semibold text-neutral-500">Try sample file:</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {SAMPLE_URLS.slice(0, 4).map((sample) => (
                  <button
                    key={sample.url}
                    type="button"
                    onClick={() => {
                      setUrlInput(sample.url);
                      setUrlError(null);
                    }}
                    className="flex items-center gap-1.5 rounded-lg border border-neutral-200 bg-neutral-100/70 px-2.5 py-1 text-xs font-medium text-neutral-700 hover:bg-neutral-200/70 dark:border-neutral-800 dark:bg-neutral-800/80 dark:text-neutral-300 dark:hover:bg-neutral-700"
                  >
                    <span>{sample.name}</span>
                    <span className="text-[10px] text-neutral-400">({sample.estimatedSize})</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Active Transfer Live Card */}
        {activeTransfer && (
          <section className="rounded-2xl border border-blue-200 bg-blue-50/40 p-6 shadow-sm dark:border-blue-900/40 dark:bg-blue-950/20">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-600 text-white">
                    {getFileIcon(activeTransfer.fileName, activeTransfer.mimeType)}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-neutral-900 dark:text-white">
                      {activeTransfer.fileName}
                    </h3>
                    <p className="text-xs text-neutral-500 dark:text-neutral-400">
                      Destination: <span className="font-semibold text-blue-600 dark:text-blue-400">{activeTransfer.driveFolderPath}/</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span
                    className={`rounded-full px-2.5 py-0.5 text-xs font-bold ${
                      activeTransfer.status === 'UPLOAD_COMPLETED' || activeTransfer.status === 'COMPLETED'
                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                        : activeTransfer.status === 'FAILED'
                        ? 'bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300'
                        : activeTransfer.status === 'CANCELLED'
                        ? 'bg-neutral-200 text-neutral-800 dark:bg-neutral-800 dark:text-neutral-300'
                        : 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 animate-pulse'
                    }`}
                  >
                    {activeTransfer.status}
                  </span>

                  {activeTransfer.status !== 'UPLOAD_COMPLETED' &&
                    activeTransfer.status !== 'COMPLETED' &&
                    activeTransfer.status !== 'FAILED' &&
                    activeTransfer.status !== 'CANCELLED' && (
                      <button
                        type="button"
                        onClick={handleCancelTransfer}
                        className="rounded-lg border border-neutral-300 bg-white px-2.5 py-1 text-xs font-semibold text-neutral-700 hover:bg-neutral-100 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-200"
                      >
                        Cancel
                      </button>
                    )}
                </div>
              </div>

              {/* Dual Progress Bar */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs font-semibold">
                  <span className="text-neutral-600 dark:text-neutral-300">
                    {activeTransfer.status === 'DOWNLOADING'
                      ? `1. Cloud streaming from source (${activeTransfer.downloadProgress}%)`
                      : activeTransfer.status === 'UPLOADING'
                      ? `2. Streaming into Google Drive (${activeTransfer.uploadProgress}%)`
                      : activeTransfer.status === 'UPLOAD_COMPLETED'
                      ? '✓ Transfer complete'
                      : activeTransfer.status}
                  </span>
                  <span className="text-blue-600 dark:text-blue-400">
                    {formatBytes(activeTransfer.fileSizeBytes)}
                  </span>
                </div>
                <div className="h-2.5 w-full overflow-hidden rounded-full bg-neutral-200 dark:bg-neutral-800">
                  <div
                    className={`h-full transition-all duration-300 ${
                      activeTransfer.status === 'UPLOAD_COMPLETED' || activeTransfer.status === 'COMPLETED'
                        ? 'bg-emerald-500'
                        : activeTransfer.status === 'FAILED'
                        ? 'bg-red-500'
                        : 'bg-blue-600'
                    }`}
                    style={{
                      width: `${
                        activeTransfer.status === 'UPLOAD_COMPLETED' || activeTransfer.status === 'COMPLETED'
                          ? 100
                          : activeTransfer.status === 'DOWNLOADING'
                          ? activeTransfer.downloadProgress * 0.5
                          : 50 + activeTransfer.uploadProgress * 0.5
                      }%`,
                    }}
                  />
                </div>
              </div>

              {/* Status Message Footer */}
              <div className="flex items-center justify-between text-xs text-neutral-500 dark:text-neutral-400">
                <div className="flex items-center gap-1.5">
                  <Zap className="h-3.5 w-3.5 text-emerald-500" />
                  <span>0 MB device bandwidth used (100% cloud streamed)</span>
                </div>
                {activeTransfer.status === 'UPLOAD_COMPLETED' && (
                  <a
                    href="https://drive.google.com"
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1 font-semibold text-blue-600 hover:underline dark:text-blue-400"
                  >
                    <span>View in Google Drive</span>
                    <ExternalLink className="h-3.5 w-3.5" />
                  </a>
                )}
              </div>
            </div>
          </section>
        )}

        {/* Transfer History Section */}
        <section className="rounded-2xl border border-neutral-200 bg-white p-6 shadow-sm dark:border-neutral-800 dark:bg-neutral-900">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-bold tracking-tight text-neutral-900 dark:text-white">
              Recent Transfers
            </h2>
            {history.length > 0 && (
              <button
                type="button"
                onClick={() => setHistory([])}
                className="flex items-center gap-1 text-xs text-neutral-500 hover:text-red-500 dark:text-neutral-400"
              >
                <Trash2 className="h-3.5 w-3.5" />
                <span>Clear History</span>
              </button>
            )}
          </div>

          {history.length === 0 ? (
            <div className="py-8 text-center text-xs text-neutral-400">
              No transfers yet. Paste a link above to start streaming.
            </div>
          ) : (
            <div className="divide-y divide-neutral-100 dark:divide-neutral-800">
              {history.map((item) => (
                <div key={item.id} className="py-3 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-neutral-100 dark:bg-neutral-800">
                      {getFileIcon(item.fileName, item.mimeType)}
                    </div>
                    <div className="min-w-0">
                      <div className="truncate text-xs font-semibold text-neutral-900 dark:text-white">
                        {item.fileName}
                      </div>
                      <div className="flex items-center gap-2 text-[11px] text-neutral-500">
                        <span>{formatBytes(item.fileSizeBytes)}</span>
                        <span>•</span>
                        <span>Folder: {item.driveFolderPath}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <span className="flex items-center gap-1 text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                      <CheckCircle className="h-3.5 w-3.5" />
                      <span>Uploaded</span>
                    </span>
                    <a
                      href="https://drive.google.com"
                      target="_blank"
                      rel="noreferrer"
                      className="rounded-lg p-1.5 text-neutral-400 hover:bg-neutral-100 hover:text-neutral-700 dark:hover:bg-neutral-800 dark:hover:text-neutral-200"
                      title="Open Google Drive"
                    >
                      <ExternalLink className="h-4 w-4" />
                    </a>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </main>

      {/* Modals */}
      <OAuthConnectModal
        isOpen={isOAuthOpen}
        onClose={() => setIsOAuthOpen(false)}
        onConnect={(account) => setGoogleAccount(account)}
      />

      <SetupGuideModal
        isOpen={isSetupGuideOpen}
        onClose={() => setIsSetupGuideOpen(false)}
      />
    </div>
  );
}

export default App;
