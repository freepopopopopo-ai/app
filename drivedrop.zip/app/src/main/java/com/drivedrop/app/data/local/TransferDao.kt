package com.drivedrop.app.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.drivedrop.app.data.model.TransferEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TransferDao {

    @Query("SELECT * FROM transfers ORDER BY createdAtTimestamp DESC")
    fun getAllTransfers(): Flow<List<TransferEntity>>

    @Query("SELECT * FROM transfers WHERE status NOT IN ('UPLOAD_COMPLETED', 'FAILED', 'CANCELLED') ORDER BY createdAtTimestamp DESC LIMIT 1")
    fun getActiveTransfer(): Flow<TransferEntity?>

    @Query("SELECT * FROM transfers WHERE id = :id")
    suspend fun getTransferById(id: String): TransferEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransfer(transfer: TransferEntity)

    @Update
    suspend fun updateTransfer(transfer: TransferEntity)

    @Query("UPDATE transfers SET status = :status, downloadProgress = :downloadProgress, uploadProgress = :uploadProgress, errorMessage = :errorMessage WHERE id = :id")
    suspend fun updateProgress(
        id: String,
        status: String,
        downloadProgress: Int,
        uploadProgress: Int,
        errorMessage: String? = null
    )

    @Query("DELETE FROM transfers WHERE id = :id")
    suspend fun deleteTransferById(id: String)

    @Query("DELETE FROM transfers")
    suspend fun clearAllHistory()
}
