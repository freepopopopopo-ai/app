package com.drivedrop.app.data.auth

import android.content.Context
import android.content.Intent
import android.util.Log
import com.drivedrop.app.data.local.SecurePreferences
import com.drivedrop.app.data.model.GoogleAccount
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class GoogleAuthManager(
    private val context: Context,
    private val securePreferences: SecurePreferences
) {

    private val tag = "GoogleAuthManager"

    // Use narrowest practical scope for uploading and managing files created by DriveDrop
    val driveScope = Scope("https://www.googleapis.com/auth/drive.file")

    val signInOptions: GoogleSignInOptions = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
        .requestEmail()
        .requestProfile()
        .requestScopes(driveScope)
        .build()

    val googleSignInClient: GoogleSignInClient = GoogleSignIn.getClient(context, signInOptions)

    fun getSignInIntent(): Intent {
        return googleSignInClient.signInIntent
    }

    fun handleSignInResult(account: GoogleSignInAccount?): GoogleAccount? {
        if (account == null) return null
        val googleAccount = GoogleAccount(
            email = account.email ?: "",
            displayName = account.displayName,
            photoUrl = account.photoUrl?.toString(),
            isConnected = true
        )
        securePreferences.saveAccount(googleAccount)
        Log.d(tag, "Google Drive connected for: ${googleAccount.email}")
        return googleAccount
    }

    fun getLastSignedInAccount(): GoogleSignInAccount? {
        val account = GoogleSignIn.getLastSignedInAccount(context)
        if (account != null && GoogleSignIn.hasPermissions(account, driveScope)) {
            return account
        }
        return null
    }

    fun isConnected(): Boolean {
        return securePreferences.isGoogleDriveConnected() && getLastSignedInAccount() != null
    }

    suspend fun getAccessToken(): String? = withContext(Dispatchers.IO) {
        val account = getLastSignedInAccount()?.account ?: return@withContext null
        try {
            val scopeString = "oauth2:https://www.googleapis.com/auth/drive.file"
            val token = GoogleAuthUtil.getToken(context, account, scopeString)
            token
        } catch (e: Exception) {
            Log.e(tag, "Error fetching Google Drive OAuth access token", e)
            null
        }
    }

    suspend fun disconnect(): Unit = withContext(Dispatchers.IO) {
        try {
            googleSignInClient.signOut()
            googleSignInClient.revokeAccess()
        } catch (e: Exception) {
            Log.e(tag, "Error during Google Sign-Out / Revoke", e)
        }
        securePreferences.clearAccount()
    }
}
