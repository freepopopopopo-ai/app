package com.drivedrop.app.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drivedrop.app.data.model.TransferEntity
import com.drivedrop.app.data.model.TransferStatus
import com.drivedrop.app.ui.theme.GoogleBlue
import com.drivedrop.app.ui.theme.GoogleGreen
import com.drivedrop.app.ui.theme.GoogleRed
import com.drivedrop.app.ui.theme.GoogleYellow
import com.drivedrop.app.utils.UrlValidator

@Composable
fun TransferProgressCard(
    transfer: TransferEntity,
    onCancel: (String) -> Unit,
    onRetry: (TransferEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            // Header: Status indicator & Title
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(
                                when (transfer.status) {
                                    TransferStatus.UPLOAD_COMPLETED -> GoogleGreen.copy(alpha = 0.15f)
                                    TransferStatus.FAILED -> GoogleRed.copy(alpha = 0.15f)
                                    TransferStatus.DOWNLOADING, TransferStatus.DOWNLOAD_COMPLETE -> GoogleBlue.copy(alpha = 0.15f)
                                    TransferStatus.UPLOADING, TransferStatus.AUTHENTICATING -> GoogleYellow.copy(alpha = 0.2f)
                                    else -> MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (transfer.status) {
                                TransferStatus.UPLOAD_COMPLETED -> Icons.Default.CheckCircle
                                TransferStatus.FAILED -> Icons.Default.Error
                                TransferStatus.DOWNLOADING, TransferStatus.DOWNLOAD_COMPLETE -> Icons.Default.Download
                                else -> Icons.Default.CloudUpload
                            },
                            contentDescription = null,
                            tint = when (transfer.status) {
                                TransferStatus.UPLOAD_COMPLETED -> GoogleGreen
                                TransferStatus.FAILED -> GoogleRed
                                TransferStatus.DOWNLOADING, TransferStatus.DOWNLOAD_COMPLETE -> GoogleBlue
                                else -> GoogleBlue
                            },
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Current Transfer",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = transfer.fileName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                if (transfer.fileSizeBytes > 0) {
                    Text(
                        text = UrlValidator.formatBytes(transfer.fileSizeBytes),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Stage 1: Download Progress
            if (transfer.status == TransferStatus.DOWNLOADING ||
                transfer.status == TransferStatus.DOWNLOAD_COMPLETE ||
                transfer.status == TransferStatus.AUTHENTICATING ||
                transfer.status == TransferStatus.UPLOADING ||
                transfer.status == TransferStatus.UPLOAD_COMPLETED
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (transfer.status == TransferStatus.DOWNLOADING) "Downloading…" else "✓ Download complete",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = if (transfer.status == TransferStatus.DOWNLOADING) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (transfer.status == TransferStatus.DOWNLOADING) GoogleBlue else MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${transfer.downloadProgress}%",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { transfer.downloadProgress / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = GoogleBlue,
                        trackColor = MaterialTheme.colorScheme.surface
                    )
                }
            }

            // Stage 2: Upload Progress
            if (transfer.status == TransferStatus.UPLOADING ||
                transfer.status == TransferStatus.UPLOAD_COMPLETED ||
                transfer.status == TransferStatus.AUTHENTICATING
            ) {
                Spacer(modifier = Modifier.height(14.dp))
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = when (transfer.status) {
                                TransferStatus.AUTHENTICATING -> "Connecting to Google Drive…"
                                TransferStatus.UPLOADING -> "Uploading to Google Drive…"
                                else -> "✓ Upload completed"
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = if (transfer.status == TransferStatus.UPLOADING) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (transfer.status == TransferStatus.UPLOAD_COMPLETED) GoogleGreen else GoogleBlue
                        )
                        Text(
                            text = "${transfer.uploadProgress}%",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { transfer.uploadProgress / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = if (transfer.status == TransferStatus.UPLOAD_COMPLETED) GoogleGreen else GoogleBlue,
                        trackColor = MaterialTheme.colorScheme.surface
                    )
                }
            }

            // Stage 3: Completion Result Details
            if (transfer.status == TransferStatus.UPLOAD_COMPLETED) {
                Spacer(modifier = Modifier.height(14.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(GoogleGreen.copy(alpha = 0.1f))
                        .padding(12.dp)
                ) {
                    Column {
                        Text(
                            text = "✓ Upload completed",
                            style = MaterialTheme.typography.labelLarge,
                            color = GoogleGreen,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "File: ${transfer.fileName}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "Google Drive: ${transfer.driveFolderPath}/${transfer.fileName}",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            // Error Display
            if (transfer.status == TransferStatus.FAILED) {
                Spacer(modifier = Modifier.height(12.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(GoogleRed.copy(alpha = 0.1f))
                        .padding(12.dp)
                ) {
                    Column {
                        Text(
                            text = "Transfer failed",
                            style = MaterialTheme.typography.labelLarge,
                            color = GoogleRed,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = transfer.errorMessage ?: "Unknown error occurred during transfer.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(
                        onClick = { onRetry(transfer) },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = GoogleBlue)
                    ) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Retry")
                    }
                }
            }
        }
    }
}
