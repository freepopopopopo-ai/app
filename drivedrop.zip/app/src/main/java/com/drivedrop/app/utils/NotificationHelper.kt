package com.drivedrop.app.utils

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.drivedrop.app.DriveDropApp
import com.drivedrop.app.MainActivity
import com.drivedrop.app.R

class NotificationHelper(private val context: Context) {

    private val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun createForegroundNotification(
        transferId: String,
        fileName: String,
        isDownloading: Boolean,
        progressPercent: Int
    ): Notification {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("EXTRA_TRANSFER_ID", transferId)
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            transferId.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )

        val title = context.getString(R.string.app_name)
        val actionText = if (isDownloading) "Downloading $fileName" else "Uploading $fileName to Google Drive"
        val contentText = "$actionText ($progressPercent%)"

        val builder = NotificationCompat.Builder(context, DriveDropApp.NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setContentText(contentText)
            .setSubText(if (isDownloading) "Downloading…" else "Uploading…")
            .setProgress(100, progressPercent, progressPercent == 0)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)

        return builder.build()
    }

    fun showCompletionNotification(
        notificationId: Int,
        fileName: String,
        isSuccess: Boolean,
        errorMessage: String? = null
    ) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )

        val title = if (isSuccess) "✓ Upload completed" else "Transfer failed"
        val content = if (isSuccess) "$fileName is now in Google Drive/DriveDrop" else (errorMessage ?: "Error transferring $fileName")

        val builder = NotificationCompat.Builder(context, DriveDropApp.NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(if (isSuccess) android.R.drawable.stat_sys_upload_done else android.R.drawable.stat_notify_error)
            .setContentTitle(title)
            .setContentText(content)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)

        notificationManager.notify(notificationId, builder.build())
    }
}
