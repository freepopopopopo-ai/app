package com.drivedrop.app.data.model

enum class TransferStatus {
    IDLE,
    VALIDATING,
    DOWNLOADING,
    DOWNLOAD_COMPLETE,
    AUTHENTICATING,
    UPLOADING,
    UPLOAD_COMPLETED,
    FAILED,
    CANCELLED
}
