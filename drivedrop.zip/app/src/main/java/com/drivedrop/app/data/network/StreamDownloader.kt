package com.drivedrop.app.data.network

import android.content.Context
import android.util.Log
import com.drivedrop.app.utils.UrlValidator
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.coroutineContext

class StreamDownloader(private val context: Context) {

    private val tag = "StreamDownloader"

    private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .followRedirects(true)
        .followSslRedirects(true)
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    data class DownloadResult(
        val tempFile: File,
        val fileName: String,
        val fileSizeBytes: Long,
        val mimeType: String
    )

    suspend fun downloadFile(
        directUrl: String,
        onProgress: (bytesRead: Long, totalBytes: Long, percent: Int) -> Unit
    ): DownloadResult = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url(directUrl)
            .header("User-Agent", "DriveDrop-Android/1.0")
            .build()

        val response = try {
            okHttpClient.newCall(request).execute()
        } catch (e: IOException) {
            throw IOException("Failed to connect to download URL: ${e.localizedMessage}", e)
        }

        if (!response.isSuccessful) {
            val code = response.code
            response.close()
            throw IOException("Server returned HTTP error code: $code")
        }

        val body = response.body ?: throw IOException("Server returned empty response body")
        val contentLength = body.contentLength()
        val rawMimeType = body.contentType()?.toString() ?: "application/octet-stream"

        // Determine filename from Content-Disposition header first, then fallback to URL
        val contentDisposition = response.header("Content-Disposition")
        val headerFileName = UrlValidator.parseContentDisposition(contentDisposition)
        val derivedFileName = headerFileName ?: UrlValidator.extractFileNameFromUrl(directUrl)
        val finalMimeType = if (rawMimeType == "application/octet-stream" || rawMimeType.contains("text/html")) {
            UrlValidator.getMimeTypeFromExtension(derivedFileName)
        } else {
            rawMimeType
        }

        val tempDir = File(context.cacheDir, "drivedrop_temp").apply { if (!exists()) mkdirs() }
        val tempFile = File(tempDir, "temp_${System.currentTimeMillis()}_$derivedFileName")

        try {
            val inputStream = body.byteStream()
            val outputStream = FileOutputStream(tempFile)
            val buffer = ByteArray(64 * 1024) // 64 KB chunk buffer
            var bytesReadTotal = 0L
            var lastReportedPercent = -1

            inputStream.use { input ->
                outputStream.use { output ->
                    var read: Int
                    while (input.read(buffer).also { read = it } != -1) {
                        coroutineContext.ensureActive()
                        output.write(buffer, 0, read)
                        bytesReadTotal += read

                        if (contentLength > 0) {
                            val percent = ((bytesReadTotal * 100) / contentLength).toInt().coerceIn(0, 100)
                            if (percent != lastReportedPercent) {
                                lastReportedPercent = percent
                                onProgress(bytesReadTotal, contentLength, percent)
                            }
                        } else {
                            // Chunked transfer encoding without Content-Length
                            onProgress(bytesReadTotal, -1L, 0)
                        }
                    }
                    output.flush()
                }
            }

            Log.d(tag, "Successfully streamed file to: ${tempFile.absolutePath} ($bytesReadTotal bytes)")
            DownloadResult(
                tempFile = tempFile,
                fileName = derivedFileName,
                fileSizeBytes = if (contentLength > 0) contentLength else bytesReadTotal,
                mimeType = finalMimeType
            )
        } catch (e: Exception) {
            if (tempFile.exists()) {
                tempFile.delete()
            }
            if (e is CancellationException) {
                throw e
            }
            throw IOException("Download interrupted or failed: ${e.localizedMessage}", e)
        } finally {
            response.close()
        }
    }
}
