package com.drivedrop.app.data.local

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.drivedrop.app.data.model.GoogleAccount
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SecurePreferences(private val context: Context) {

    private val tag = "SecurePreferences"
    private val prefs: SharedPreferences

    private val _accountState = MutableStateFlow<GoogleAccount?>(null)
    val accountState: StateFlow<GoogleAccount?> = _accountState.asStateFlow()

    init {
        prefs = createSharedPreferences()
        loadAccount()
    }

    private fun createSharedPreferences(): SharedPreferences {
        return try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()

            EncryptedSharedPreferences.create(
                context,
                "drivedrop_secure_prefs",
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            Log.e(tag, "EncryptedSharedPreferences init failed, falling back to standard prefs", e)
            context.getSharedPreferences("drivedrop_fallback_prefs", Context.MODE_PRIVATE)
        }
    }

    private fun loadAccount() {
        val isConnected = prefs.getBoolean(KEY_IS_CONNECTED, false)
        if (isConnected) {
            val email = prefs.getString(KEY_EMAIL, null) ?: return
            val displayName = prefs.getString(KEY_DISPLAY_NAME, null)
            val photoUrl = prefs.getString(KEY_PHOTO_URL, null)
            _accountState.value = GoogleAccount(
                email = email,
                displayName = displayName,
                photoUrl = photoUrl,
                isConnected = true
            )
        } else {
            _accountState.value = null
        }
    }

    fun saveAccount(account: GoogleAccount) {
        prefs.edit().apply {
            putBoolean(KEY_IS_CONNECTED, true)
            putString(KEY_EMAIL, account.email)
            putString(KEY_DISPLAY_NAME, account.displayName)
            putString(KEY_PHOTO_URL, account.photoUrl)
            putLong(KEY_LAST_LOGIN, System.currentTimeMillis())
            apply()
        }
        _accountState.value = account
    }

    fun clearAccount() {
        prefs.edit().apply {
            putBoolean(KEY_IS_CONNECTED, false)
            remove(KEY_EMAIL)
            remove(KEY_DISPLAY_NAME)
            remove(KEY_PHOTO_URL)
            remove(KEY_LAST_LOGIN)
            apply()
        }
        _accountState.value = null
    }

    fun isGoogleDriveConnected(): Boolean {
        return prefs.getBoolean(KEY_IS_CONNECTED, false)
    }

    fun getDefaultFolderName(): String {
        return prefs.getString(KEY_DEFAULT_FOLDER, "DriveDrop") ?: "DriveDrop"
    }

    fun setDefaultFolderName(folderName: String) {
        prefs.edit().putString(KEY_DEFAULT_FOLDER, folderName.trim()).apply()
    }

    companion object {
        private const val KEY_IS_CONNECTED = "key_is_connected"
        private const val KEY_EMAIL = "key_account_email"
        private const val KEY_DISPLAY_NAME = "key_display_name"
        private const val KEY_PHOTO_URL = "key_photo_url"
        private const val KEY_LAST_LOGIN = "key_last_login"
        private const val KEY_DEFAULT_FOLDER = "key_default_folder"
    }
}
