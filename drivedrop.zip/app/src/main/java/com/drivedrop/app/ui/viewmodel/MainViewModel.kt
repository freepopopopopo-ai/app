package com.drivedrop.app.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.drivedrop.app.DriveDropApp
import com.drivedrop.app.data.auth.GoogleAuthManager
import com.drivedrop.app.data.model.GoogleAccount
import com.drivedrop.app.data.model.TransferEntity
import com.drivedrop.app.data.model.TransferStatus
import com.drivedrop.app.data.network.CloudApiService
import com.drivedrop.app.utils.UrlValidator
import com.drivedrop.app.work.WorkManagerHelper
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val app = getApplication<DriveDropApp>()
    private val database = app.database
    private val securePreferences = app.securePreferences
    private val workManagerHelper = WorkManagerHelper(application)
    val authManager = GoogleAuthManager(application, securePreferences)
    private val cloudApiService = CloudApiService()

    // UI Input State
    private val _urlInput = MutableStateFlow("")
    val urlInput: StateFlow<String> = _urlInput.asStateFlow()

    private val _urlError = MutableStateFlow<String?>(null)
    val urlError: StateFlow<String?> = _urlError.asStateFlow()

    private val _isStarting = MutableStateFlow(false)
    val isStarting: StateFlow<Boolean> = _isStarting.asStateFlow()

    // Google Drive Connected Account
    val accountState: StateFlow<GoogleAccount?> = securePreferences.accountState

    // Active Transfer & History from Room DB
    val activeTransfer: StateFlow<TransferEntity?> = database.transferDao()
        .getActiveTransfer()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val historyList: StateFlow<List<TransferEntity>> = database.transferDao()
        .getAllTransfers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun onUrlChanged(newUrl: String) {
        _urlInput.value = newUrl
        if (_urlError.value != null) {
            _urlError.value = null
        }
    }

    fun handleSharedUrl(sharedText: String?) {
        if (!sharedText.isNullOrBlank()) {
            val extracted = extractUrlFromString(sharedText)
            if (extracted != null) {
                _urlInput.value = extracted
            }
        }
    }

    private fun extractUrlFromString(text: String): String? {
        val trimmed = text.trim()
        if (UrlValidator.isValidDirectUrl(trimmed)) {
            return trimmed
        }
        val parts = trimmed.split("\\s+".toRegex())
        return parts.firstOrNull { UrlValidator.isValidDirectUrl(it) }
    }

    fun handleGoogleSignInResult(account: GoogleSignInAccount?) {
        authManager.handleSignInResult(account)
    }

    /**
     * Start Cloud Transfer (Option 2):
     * The phone submits the direct URL to the cloud backend.
     * The cloud performs URL -> Download -> Google Drive.
     * The phone only monitors job status via lightweight metadata.
     */
    fun startTransfer(onRequireAuth: () -> Unit) {
        val url = _urlInput.value.trim()
        if (!UrlValidator.isValidDirectUrl(url)) {
            _urlError.value = "Please enter a valid HTTP or HTTPS direct download URL"
            return
        }

        if (!authManager.isConnected()) {
            onRequireAuth()
            return
        }

        viewModelScope.launch {
            _isStarting.value = true
            try {
                val folder = securePreferences.getDefaultFolderName()
                val token = authManager.getAccessToken()

                val response = cloudApiService.submitUploadJob(
                    directUrl = url,
                    folderName = folder,
                    authToken = token
                )

                val transferId = UUID.randomUUID().toString()
                val initialEntity = TransferEntity(
                    id = transferId,
                    directUrl = url,
                    fileName = response.fileName,
                    status = TransferStatus.QUEUED,
                    downloadProgress = 0,
                    uploadProgress = 0,
                    driveFolderPath = folder
                )

                database.transferDao().insertTransfer(initialEntity)
                workManagerHelper.startTransfer(transferId, url, response.fileName)

                _urlInput.value = ""
                _urlError.value = null
            } catch (e: Exception) {
                _urlError.value = "Cloud transfer submission failed: ${e.localizedMessage ?: e.message}"
            } finally {
                _isStarting.value = false
            }
        }
    }

    fun retryTransfer(transfer: TransferEntity) {
        viewModelScope.launch {
            val newId = UUID.randomUUID().toString()
            val retriedEntity = transfer.copy(
                id = newId,
                status = TransferStatus.QUEUED,
                downloadProgress = 0,
                uploadProgress = 0,
                errorMessage = null,
                createdAtTimestamp = System.currentTimeMillis(),
                completedAtTimestamp = null
            )
            database.transferDao().insertTransfer(retriedEntity)
            workManagerHelper.startTransfer(newId, transfer.directUrl, transfer.fileName)
        }
    }

    fun cancelTransfer(transferId: String) {
        viewModelScope.launch {
            workManagerHelper.cancelTransfer(transferId)
            val item = database.transferDao().getTransferById(transferId)
            if (item != null) {
                database.transferDao().updateTransfer(
                    item.copy(status = TransferStatus.CANCELLED, errorMessage = "Cancelled by user")
                )
            }
        }
    }

    fun deleteHistoryItem(id: String) {
        viewModelScope.launch {
            database.transferDao().deleteTransferById(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            database.transferDao().clearAllHistory()
        }
    }
}
