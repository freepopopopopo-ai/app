package com.drivedrop.app.data.model

data class UploadRequest(
    val url: String,
    val folderName: String = "DriveDrop",
    val customFileName: String? = null
)

data class UploadResponse(
    val jobId: String,
    val status: String,
    val fileName: String,
    val message: String,
    val createdAt: Long
)

data class CloudJobStatusResponse(
    val jobId: String,
    val status: String,
    val progress: Int,
    val downloadProgress: Int,
    val uploadProgress: Int,
    val downloadSpeedMBs: Double = 0.0,
    val uploadSpeedMBs: Double = 0.0,
    val fileName: String,
    val fileSizeBytes: Long = 0L,
    val mimeType: String = "application/octet-stream",
    val message: String = "",
    val driveFileId: String? = null,
    val driveFolderPath: String = "DriveDrop",
    val error: String? = null
)
