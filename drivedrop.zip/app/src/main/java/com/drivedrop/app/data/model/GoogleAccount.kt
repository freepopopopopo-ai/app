package com.drivedrop.app.data.model

data class GoogleAccount(
    val email: String,
    val displayName: String?,
    val photoUrl: String?,
    val isConnected: Boolean = true,
    val lastConnectedTime: Long = System.currentTimeMillis()
)
