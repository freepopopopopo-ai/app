package com.drivedrop.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "transfers")
data class TransferEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val directUrl: String,
    val fileName: String,
    val fileSizeBytes: Long = 0L,
    val mimeType: String = "application/octet-stream",
    val status: TransferStatus = TransferStatus.IDLE,
    val downloadProgress: Int = 0,
    val uploadProgress: Int = 0,
    val errorMessage: String? = null,
    val driveFileId: String? = null,
    val driveFolderPath: String = "DriveDrop",
    val createdAtTimestamp: Long = System.currentTimeMillis(),
    val completedAtTimestamp: Long? = null
)
