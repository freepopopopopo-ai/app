package com.drivedrop.app.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.drivedrop.app.DriveDropApp
import com.drivedrop.app.data.auth.GoogleAuthManager
import com.drivedrop.app.data.model.GoogleAccount
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val app = getApplication<DriveDropApp>()
    private val securePreferences = app.securePreferences
    val authManager = GoogleAuthManager(application, securePreferences)

    val accountState: StateFlow<GoogleAccount?> = securePreferences.accountState

    private val _folderName = MutableStateFlow(securePreferences.getDefaultFolderName())
    val folderName: StateFlow<String> = _folderName.asStateFlow()

    fun updateFolderName(name: String) {
        _folderName.value = name
        securePreferences.setDefaultFolderName(name)
    }

    fun disconnectGoogleDrive() {
        viewModelScope.launch {
            authManager.disconnect()
        }
    }
}
