package com.drivedrop.app.utils

import android.webkit.URLUtil
import java.net.URI
import java.net.URLDecoder
import java.text.DecimalFormat
import java.util.Locale
import java.util.regex.Pattern

object UrlValidator {

    private val URL_REGEX = Pattern.compile(
        "^(https?|ftp)://[-a-zA-Z0-9+&@#/%?=~_|!:,.;]*[-a-zA-Z0-9+&@#/%=~_|]",
        Pattern.CASE_INSENSITIVE
    )

    fun isValidDirectUrl(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        val trimmed = url.trim()
        if (!trimmed.startsWith("http://", ignoreCase = true) &&
            !trimmed.startsWith("https://", ignoreCase = true)
        ) {
            return false
        }
        return try {
            val uri = URI(trimmed)
            uri.host != null && uri.host.isNotEmpty()
        } catch (e: Exception) {
            false
        }
    }

    fun extractFileNameFromUrl(url: String): String {
        return try {
            val decodedUrl = URLDecoder.decode(url, "UTF-8")
            val uri = URI(decodedUrl)
            val path = uri.path ?: ""
            val lastSegment = path.substringAfterLast('/')
            val cleanSegment = lastSegment.substringBefore('?').substringBefore('#')

            if (cleanSegment.isNotBlank() && cleanSegment.contains('.')) {
                cleanSegment
            } else if (cleanSegment.isNotBlank()) {
                cleanSegment
            } else {
                "drivedrop_download_${System.currentTimeMillis()}"
            }
        } catch (e: Exception) {
            val guessed = URLUtil.guessFileName(url, null, null)
            if (guessed.isNotBlank() && guessed != "downloadfile") {
                guessed
            } else {
                "drivedrop_file_${System.currentTimeMillis()}"
            }
        }
    }

    fun parseContentDisposition(contentDisposition: String?): String? {
        if (contentDisposition.isNullOrBlank()) return null
        return try {
            // Check filename*=UTF-8''... (RFC 5987)
            val utf8Matcher = Pattern.compile("filename\\*=UTF-8''([^;]+)", Pattern.CASE_INSENSITIVE).matcher(contentDisposition)
            if (utf8Matcher.find()) {
                return URLDecoder.decode(utf8Matcher.group(1), "UTF-8")
            }

            // Check standard filename="xyz" or filename=xyz
            val standardMatcher = Pattern.compile("filename=[\"']?([^\"';]+)[\"']?", Pattern.CASE_INSENSITIVE).matcher(contentDisposition)
            if (standardMatcher.find()) {
                return standardMatcher.group(1)?.trim()
            }
            null
        } catch (e: Exception) {
            null
        }
    }

    fun formatBytes(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
        val index = Math.min(digitGroups, units.size - 1)
        val df = DecimalFormat("#,##0.#")
        return "${df.format(bytes / Math.pow(1024.0, index.toDouble()))} ${units[index]}"
    }

    fun getMimeTypeFromExtension(fileName: String): String {
        val extension = fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)
        return when (extension) {
            "mp4" -> "video/mp4"
            "mkv" -> "video/x-matroska"
            "avi" -> "video/x-msvideo"
            "mov" -> "video/quicktime"
            "webm" -> "video/webm"
            "mp3" -> "audio/mpeg"
            "wav" -> "audio/wav"
            "flac" -> "audio/flac"
            "pdf" -> "application/pdf"
            "zip" -> "application/zip"
            "rar" -> "application/x-rar-compressed"
            "7z" -> "application/x-7z-compressed"
            "tar" -> "application/x-tar"
            "gz" -> "application/gzip"
            "apk" -> "application/vnd.android.package-archive"
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "webp" -> "image/webp"
            "gif" -> "image/gif"
            "svg" -> "image/svg+xml"
            "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            "pptx" -> "application/vnd.openxmlformats-officedocument.presentationml.presentation"
            "txt" -> "text/plain"
            "json" -> "application/json"
            else -> "application/octet-stream"
        }
    }
}
