package com.drivedrop.app.data.drive

import android.content.Context
import android.util.Log
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.coroutineContext

class GoogleDriveService(private val context: Context) {

    private val tag = "GoogleDriveService"

    private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    /**
     * Finds or creates the target folder (e.g. "DriveDrop") in the user's Google Drive.
     */
    suspend fun getOrCreateFolder(folderName: String, accessToken: String): String = withContext(Dispatchers.IO) {
        val query = "mimeType = 'application/vnd.google-apps.folder' and name = '$folderName' and trashed = false and 'root' in parents"
        val encodedQuery = java.net.URLEncoder.encode(query, "UTF-8")
        val searchUrl = "https://www.googleapis.com/drive/v3/files?q=$encodedQuery&fields=files(id,name)&spaces=drive"

        val searchRequest = Request.Builder()
            .url(searchUrl)
            .header("Authorization", "Bearer $accessToken")
            .get()
            .build()

        val searchResponse = try {
            okHttpClient.newCall(searchRequest).execute()
        } catch (e: IOException) {
            throw IOException("Failed to communicate with Google Drive API: ${e.localizedMessage}", e)
        }

        if (!searchResponse.isSuccessful) {
            val errBody = searchResponse.body?.string() ?: ""
            searchResponse.close()
            throw IOException("Google Drive search error (HTTP ${searchResponse.code}): $errBody")
        }

        val responseBody = searchResponse.body?.string() ?: "{}"
        searchResponse.close()

        val json = JSONObject(responseBody)
        val files = json.optJSONArray("files")
        if (files != null && files.length() > 0) {
            val existingFolderId = files.getJSONObject(0).getString("id")
            Log.d(tag, "Found existing Drive folder '$folderName' with ID: $existingFolderId")
            return@withContext existingFolderId
        }

        // Folder not found; create it
        Log.d(tag, "Folder '$folderName' not found; creating new folder in Google Drive root")
        val createUrl = "https://www.googleapis.com/drive/v3/files"
        val folderMeta = JSONObject().apply {
            put("name", folderName)
            put("mimeType", "application/vnd.google-apps.folder")
            put("parents", JSONArray().put("root"))
        }

        val createRequest = Request.Builder()
            .url(createUrl)
            .header("Authorization", "Bearer $accessToken")
            .header("Content-Type", "application/json; charset=UTF-8")
            .post(folderMeta.toString().toRequestBody("application/json; charset=UTF-8".toMediaType()))
            .build()

        val createResponse = okHttpClient.newCall(createRequest).execute()
        if (!createResponse.isSuccessful) {
            val err = createResponse.body?.string() ?: ""
            createResponse.close()
            throw IOException("Failed to create Google Drive folder '$folderName': $err")
        }

        val createdJson = JSONObject(createResponse.body?.string() ?: "{}")
        createResponse.close()
        val newFolderId = createdJson.getString("id")
        Log.d(tag, "Created new folder '$folderName' with ID: $newFolderId")
        newFolderId
    }

    /**
     * Performs a stream-based resumable upload to Google Drive.
     */
    suspend fun uploadFileResumable(
        file: File,
        fileName: String,
        mimeType: String,
        folderId: String?,
        accessToken: String,
        onProgress: (bytesUploaded: Long, totalBytes: Long, percent: Int) -> Unit
    ): String = withContext(Dispatchers.IO) {
        val totalFileSize = file.length()
        if (totalFileSize == 0L) {
            throw IOException("File to upload is empty (0 bytes).")
        }

        // Step 1: Initiate Resumable Upload Session
        val metadata = JSONObject().apply {
            put("name", fileName)
            if (!folderId.isNullOrBlank()) {
                put("parents", JSONArray().put(folderId))
            }
        }

        val initUrl = "https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable"
        val initRequest = Request.Builder()
            .url(initUrl)
            .header("Authorization", "Bearer $accessToken")
            .header("X-Upload-Content-Type", mimeType)
            .header("X-Upload-Content-Length", totalFileSize.toString())
            .header("Content-Type", "application/json; charset=UTF-8")
            .post(metadata.toString().toRequestBody("application/json; charset=UTF-8".toMediaType()))
            .build()

        val initResponse = try {
            okHttpClient.newCall(initRequest).execute()
        } catch (e: IOException) {
            throw IOException("Failed to initiate Google Drive resumable upload: ${e.localizedMessage}", e)
        }

        if (initResponse.code != 200 && initResponse.code != 201) {
            val err = initResponse.body?.string() ?: ""
            initResponse.close()
            throw IOException("Failed to start Drive upload session (HTTP ${initResponse.code}): $err")
        }

        val sessionLocation = initResponse.header("Location")
            ?: run {
                initResponse.close()
                throw IOException("Google Drive did not return a resumable session URI Location header.")
            }
        initResponse.close()

        Log.d(tag, "Started resumable upload session for '$fileName'. Session URI obtained.")

        // Step 2: Upload Chunks (256 KB multiples: 1 MB chunks)
        val chunkSize = 1024 * 1024 // 1 MB
        var bytesUploaded = 0L
        val fileInputStream = FileInputStream(file)
        var driveFileId: String? = null

        fileInputStream.use { stream ->
            while (bytesUploaded < totalFileSize) {
                coroutineContext.ensureActive()

                val currentChunkSize = Math.min(chunkSize.toLong(), totalFileSize - bytesUploaded).toInt()
                val chunkBuffer = ByteArray(currentChunkSize)
                var readInChunk = 0
                while (readInChunk < currentChunkSize) {
                    val read = stream.read(chunkBuffer, readInChunk, currentChunkSize - readInChunk)
                    if (read == -1) break
                    readInChunk += read
                }

                val startByte = bytesUploaded
                val endByte = startByte + readInChunk - 1
                val contentRange = "bytes $startByte-$endByte/$totalFileSize"

                val chunkRequestBody = chunkBuffer.toRequestBody(mimeType.toMediaType(), 0, readInChunk)
                val uploadChunkRequest = Request.Builder()
                    .url(sessionLocation)
                    .header("Content-Range", contentRange)
                    .header("Content-Length", readInChunk.toString())
                    .put(chunkRequestBody)
                    .build()

                val chunkResponse = okHttpClient.newCall(uploadChunkRequest).execute()
                val code = chunkResponse.code

                if (code == 200 || code == 201) {
                    // Upload finished!
                    val finishBody = chunkResponse.body?.string() ?: "{}"
                    chunkResponse.close()
                    val json = JSONObject(finishBody)
                    driveFileId = json.optString("id")
                    bytesUploaded += readInChunk
                    onProgress(totalFileSize, totalFileSize, 100)
                    Log.d(tag, "Drive upload complete. File ID: $driveFileId")
                    break
                } else if (code == 308) {
                    // Incomplete, continue next chunk
                    chunkResponse.close()
                    bytesUploaded += readInChunk
                    val percent = ((bytesUploaded * 100) / totalFileSize).toInt().coerceIn(0, 99)
                    onProgress(bytesUploaded, totalFileSize, percent)
                } else {
                    val err = chunkResponse.body?.string() ?: ""
                    chunkResponse.close()
                    throw IOException("Chunk upload failed (HTTP $code): $err")
                }
            }
        }

        driveFileId ?: throw IOException("Drive upload completed without receiving a file ID.")
    }
}
