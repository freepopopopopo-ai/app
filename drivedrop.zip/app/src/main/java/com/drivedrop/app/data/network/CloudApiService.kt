package com.drivedrop.app.data.network

import com.drivedrop.app.data.model.CloudJobStatusResponse
import com.drivedrop.app.data.model.UploadRequest
import com.drivedrop.app.data.model.UploadResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * CloudApiService: Android Network Client for Option 2 Architecture.
 *
 * Sends the direct download URL to the Google Cloud Run backend.
 * The Android device uses ONLY lightweight JSON metadata.
 * The large file payload NEVER touches the Android phone.
 */
class CloudApiService(private val backendBaseUrl: String = "https://drivedrop-backend-run.app") {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private val jsonMedia = "application/json; charset=utf-8".toMediaType()

    /**
     * POST /api/upload
     * Sends the direct URL to the cloud backend. Phone NEVER downloads the file.
     */
    suspend fun submitUploadJob(
        directUrl: String,
        folderName: String = "DriveDrop",
        customFileName: String? = null,
        authToken: String? = null
    ): UploadResponse = withContext(Dispatchers.IO) {
        val jsonPayload = JSONObject().apply {
            put("url", directUrl)
            put("folderName", folderName)
            if (!customFileName.isNullOrBlank()) {
                put("customFileName", customFileName)
            }
        }

        val requestBuilder = Request.Builder()
            .url("$backendBaseUrl/api/upload")
            .post(jsonPayload.toString().toRequestBody(jsonMedia))

        authToken?.let {
            requestBuilder.header("Authorization", "Bearer $it")
        }

        val response = client.newCall(requestBuilder.build()).execute()
        val bodyString = response.body?.string() ?: throw IOException("Empty response from backend")

        if (!response.isSuccessful) {
            val errObj = try { JSONObject(bodyString) } catch (_: Exception) { JSONObject() }
            val msg = errObj.optString("message", "HTTP ${response.code} error from cloud backend")
            throw IOException(msg)
        }

        val json = JSONObject(bodyString)
        UploadResponse(
            jobId = json.getString("jobId"),
            status = json.getString("status"),
            fileName = json.optString("fileName", "file"),
            message = json.optString("message", "Job queued on cloud"),
            createdAt = json.optLong("createdAt", System.currentTimeMillis())
        )
    }

    /**
     * GET /api/upload/{jobId}/status
     * Retrieves cloud transfer progress (downloading from source vs uploading to Drive).
     */
    suspend fun getJobStatus(jobId: String, authToken: String? = null): CloudJobStatusResponse = withContext(Dispatchers.IO) {
        val requestBuilder = Request.Builder()
            .url("$backendBaseUrl/api/upload/$jobId/status")
            .get()

        authToken?.let {
            requestBuilder.header("Authorization", "Bearer $it")
        }

        val response = client.newCall(requestBuilder.build()).execute()
        val bodyString = response.body?.string() ?: throw IOException("Empty response from backend")

        if (!response.isSuccessful) {
            throw IOException("HTTP ${response.code}: Failed to query job status")
        }

        val json = JSONObject(bodyString)
        CloudJobStatusResponse(
            jobId = json.getString("jobId"),
            status = json.getString("status"),
            progress = json.optInt("progress", 0),
            downloadProgress = json.optInt("downloadProgress", 0),
            uploadProgress = json.optInt("uploadProgress", 0),
            downloadSpeedMBs = json.optDouble("downloadSpeedMBs", 0.0),
            uploadSpeedMBs = json.optDouble("uploadSpeedMBs", 0.0),
            fileName = json.optString("fileName", "unknown"),
            fileSizeBytes = json.optLong("fileSizeBytes", 0L),
            mimeType = json.optString("mimeType", "application/octet-stream"),
            message = json.optString("message", ""),
            driveFileId = json.optString("driveFileId", null),
            driveFolderPath = json.optString("driveFolderPath", "DriveDrop"),
            error = json.optString("error", null)
        )
    }

    /**
     * POST /api/upload/{jobId}/cancel
     */
    suspend fun cancelJob(jobId: String): Boolean = withContext(Dispatchers.IO) {
        val req = Request.Builder()
            .url("$backendBaseUrl/api/upload/$jobId/cancel")
            .post("{}".toRequestBody(jsonMedia))
            .build()
        val res = client.newCall(req).execute()
        res.isSuccessful
    }
}
