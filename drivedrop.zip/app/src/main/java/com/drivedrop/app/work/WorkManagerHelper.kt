package com.drivedrop.app.work

import android.content.Context
import androidx.lifecycle.asFlow
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.work.workDataOf
import kotlinx.coroutines.flow.Flow
import java.util.concurrent.TimeUnit

class WorkManagerHelper(private val context: Context) {

    private val workManager = WorkManager.getInstance(context)

    fun startTransfer(
        transferId: String,
        directUrl: String,
        customFileName: String? = null
    ) {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val inputData = workDataOf(
            DriveDropWorker.KEY_TRANSFER_ID to transferId,
            DriveDropWorker.KEY_DIRECT_URL to directUrl,
            DriveDropWorker.KEY_CUSTOM_FILENAME to customFileName
        )

        val workRequest = OneTimeWorkRequestBuilder<DriveDropWorker>()
            .setConstraints(constraints)
            .setInputData(inputData)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.SECONDS)
            .addTag("TAG_TRANSFER_$transferId")
            .addTag("TAG_ALL_TRANSFERS")
            .build()

        workManager.enqueueUniqueWork(
            "WORK_$transferId",
            ExistingWorkPolicy.REPLACE,
            workRequest
        )
    }

    fun getWorkInfoFlow(transferId: String): Flow<List<WorkInfo>> {
        return workManager.getWorkInfosForUniqueWorkLiveData("WORK_$transferId").asFlow()
    }

    fun cancelTransfer(transferId: String) {
        workManager.cancelUniqueWork("WORK_$transferId")
    }

    fun cancelAllTransfers() {
        workManager.cancelAllWorkByTag("TAG_ALL_TRANSFERS")
    }
}
