package com.drivedrop.app.ui.theme

import androidx.compose.ui.graphics.Color

val GoogleBlue = Color(0xFF1A73E8)
val GoogleBlueDark = Color(0xFF174EA6)
val GoogleBlueLight = Color(0xFFD2E3FC)

val GoogleGreen = Color(0xFF0F9D58)
val GoogleGreenLight = Color(0xFFCEEAD6)

val GoogleRed = Color(0xFFD93025)
val GoogleYellow = Color(0xFFF9AB00)

val SurfaceLight = Color(0xFFFFFFFF)
val BackgroundLight = Color(0xFFF8F9FA)
val SurfaceVariantLight = Color(0xFFF1F3F4)
val OutlineLight = Color(0xFFDADCE0)
val OnSurfaceLight = Color(0xFF202124)
val OnSurfaceVariantLight = Color(0xFF5F6368)

val SurfaceDark = Color(0xFF1E1E1E)
val BackgroundDark = Color(0xFF121212)
val SurfaceVariantDark = Color(0xFF2D2D2D)
val OutlineDark = Color(0xFF444746)
val OnSurfaceDark = Color(0xFFE8EAED)
val OnSurfaceVariantDark = Color(0xFF9AA0A6)
