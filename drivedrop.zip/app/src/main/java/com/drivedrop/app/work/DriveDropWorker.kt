package com.drivedrop.app.work

import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.drivedrop.app.DriveDropApp
import com.drivedrop.app.data.auth.GoogleAuthManager
import com.drivedrop.app.data.drive.GoogleDriveService
import com.drivedrop.app.data.local.AppDatabase
import com.drivedrop.app.data.model.TransferEntity
import com.drivedrop.app.data.model.TransferStatus
import com.drivedrop.app.data.network.StreamDownloader
import com.drivedrop.app.utils.NotificationHelper
import com.drivedrop.app.utils.UrlValidator
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class DriveDropWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    private val tag = "DriveDropWorker"
    private val app = appContext.applicationContext as DriveDropApp
    private val database = app.database
    private val securePreferences = app.securePreferences
    private val notificationHelper = NotificationHelper(appContext)
    private val streamDownloader = StreamDownloader(appContext)
    private val googleDriveService = GoogleDriveService(appContext)
    private val authManager = GoogleAuthManager(appContext, securePreferences)

    companion object {
        const val KEY_TRANSFER_ID = "KEY_TRANSFER_ID"
        const val KEY_DIRECT_URL = "KEY_DIRECT_URL"
        const val KEY_CUSTOM_FILENAME = "KEY_CUSTOM_FILENAME"
        const val PROGRESS_STAGE = "PROGRESS_STAGE"
        const val PROGRESS_PERCENT = "PROGRESS_PERCENT"
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val transferId = inputData.getString(KEY_TRANSFER_ID) ?: id.toString()
        val directUrl = inputData.getString(KEY_DIRECT_URL)

        if (directUrl.isNullOrBlank() || !UrlValidator.isValidDirectUrl(directUrl)) {
            Log.e(tag, "Invalid URL received in worker: $directUrl")
            recordFailure(transferId, "Invalid direct download URL: $directUrl")
            return@withContext Result.failure(workDataOf("error" to "Invalid URL"))
        }

        var tempDownloadedFile: File? = null
        var initialFileName = inputData.getString(KEY_CUSTOM_FILENAME) ?: UrlValidator.extractFileNameFromUrl(directUrl)

        // Setup notification & initial Room entity
        val initialNotification = notificationHelper.createForegroundNotification(
            transferId = transferId,
            fileName = initialFileName,
            isDownloading = true,
            progressPercent = 0
        )

        try {
            val foregroundInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ForegroundInfo(
                    transferId.hashCode(),
                    initialNotification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                )
            } else {
                ForegroundInfo(transferId.hashCode(), initialNotification)
            }
            setForeground(foregroundInfo)
        } catch (e: Exception) {
            Log.w(tag, "Could not set foreground service info", e)
        }

        try {
            // STEP 1: VALIDATE & INITIALIZE
            updateStatus(transferId, TransferStatus.DOWNLOADING, downloadProgress = 0, uploadProgress = 0)

            // STEP 2: DOWNLOAD VIA STREAMING
            Log.d(tag, "Starting stream download: $directUrl")
            val downloadResult = streamDownloader.downloadFile(directUrl) { bytesRead, totalBytes, percent ->
                setProgressAsync(workDataOf(
                    PROGRESS_STAGE to "DOWNLOADING",
                    PROGRESS_PERCENT to percent
                ))
                val notif = notificationHelper.createForegroundNotification(
                    transferId = transferId,
                    fileName = initialFileName,
                    isDownloading = true,
                    progressPercent = percent
                )
                try {
                    val fgInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ForegroundInfo(transferId.hashCode(), notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
                    } else {
                        ForegroundInfo(transferId.hashCode(), notif)
                    }
                    setForegroundAsync(fgInfo)
                } catch (_: Exception) {}
            }

            tempDownloadedFile = downloadResult.tempFile
            initialFileName = downloadResult.fileName
            val fileSizeBytes = downloadResult.fileSizeBytes
            val mimeType = downloadResult.mimeType

            // Update Database with actual downloaded file info
            database.transferDao().insertTransfer(
                TransferEntity(
                    id = transferId,
                    directUrl = directUrl,
                    fileName = initialFileName,
                    fileSizeBytes = fileSizeBytes,
                    mimeType = mimeType,
                    status = TransferStatus.DOWNLOAD_COMPLETE,
                    downloadProgress = 100,
                    uploadProgress = 0
                )
            )

            // STEP 3: AUTHENTICATE GOOGLE DRIVE
            updateStatus(transferId, TransferStatus.AUTHENTICATING, downloadProgress = 100, uploadProgress = 0)
            val accessToken = authManager.getAccessToken()
            if (accessToken.isNullOrBlank()) {
                throw IllegalStateException("Google Drive is not authenticated or access token could not be obtained.")
            }

            // STEP 4: FIND OR CREATE TARGET GOOGLE DRIVE FOLDER
            val folderName = securePreferences.getDefaultFolderName()
            val folderId = googleDriveService.getOrCreateFolder(folderName, accessToken)

            // STEP 5: UPLOAD RESUMABLE STREAM TO GOOGLE DRIVE
            updateStatus(transferId, TransferStatus.UPLOADING, downloadProgress = 100, uploadProgress = 0)

            val driveFileId = googleDriveService.uploadFileResumable(
                file = tempDownloadedFile,
                fileName = initialFileName,
                mimeType = mimeType,
                folderId = folderId,
                accessToken = accessToken
            ) { bytesUploaded, totalBytes, percent ->
                setProgressAsync(workDataOf(
                    PROGRESS_STAGE to "UPLOADING",
                    PROGRESS_PERCENT to percent
                ))
                val notif = notificationHelper.createForegroundNotification(
                    transferId = transferId,
                    fileName = initialFileName,
                    isDownloading = false,
                    progressPercent = percent
                )
                try {
                    val fgInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ForegroundInfo(transferId.hashCode(), notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
                    } else {
                        ForegroundInfo(transferId.hashCode(), notif)
                    }
                    setForegroundAsync(fgInfo)
                } catch (_: Exception) {}
            }

            // STEP 6: CLEANUP TEMPORARY FILE AFTER SUCCESSFUL UPLOAD
            if (tempDownloadedFile.exists()) {
                val deleted = tempDownloadedFile.delete()
                Log.d(tag, "Temporary file deleted: $deleted")
            }

            // STEP 7: RECORD SUCCESS
            val completedEntity = TransferEntity(
                id = transferId,
                directUrl = directUrl,
                fileName = initialFileName,
                fileSizeBytes = fileSizeBytes,
                mimeType = mimeType,
                status = TransferStatus.UPLOAD_COMPLETED,
                downloadProgress = 100,
                uploadProgress = 100,
                driveFileId = driveFileId,
                driveFolderPath = folderName,
                completedAtTimestamp = System.currentTimeMillis()
            )
            database.transferDao().insertTransfer(completedEntity)

            notificationHelper.showCompletionNotification(
                notificationId = transferId.hashCode(),
                fileName = initialFileName,
                isSuccess = true
            )

            Log.i(tag, "Transfer '$initialFileName' completed successfully! Drive File ID: $driveFileId")
            Result.success(workDataOf("driveFileId" to driveFileId))

        } catch (e: Exception) {
            // Delete temp file if exists on failure
            tempDownloadedFile?.let {
                if (it.exists()) it.delete()
            }

            if (e is CancellationException) {
                Log.w(tag, "Transfer '$transferId' was cancelled.")
                updateStatus(transferId, TransferStatus.CANCELLED, 0, 0, "Cancelled by user")
                Result.failure(workDataOf("error" to "Cancelled"))
            } else {
                Log.e(tag, "Transfer '$transferId' failed: ${e.message}", e)
                recordFailure(transferId, e.localizedMessage ?: "Unknown transfer failure")
                notificationHelper.showCompletionNotification(
                    notificationId = transferId.hashCode(),
                    fileName = initialFileName,
                    isSuccess = false,
                    errorMessage = e.localizedMessage
                )
                Result.failure(workDataOf("error" to (e.localizedMessage ?: "Transfer failed")))
            }
        }
    }

    private suspend fun updateStatus(
        id: String,
        status: TransferStatus,
        downloadProgress: Int,
        uploadProgress: Int,
        errorMessage: String? = null
    ) {
        val existing = database.transferDao().getTransferById(id)
        if (existing != null) {
            database.transferDao().updateTransfer(
                existing.copy(
                    status = status,
                    downloadProgress = downloadProgress,
                    uploadProgress = uploadProgress,
                    errorMessage = errorMessage
                )
            )
        }
    }

    private suspend fun recordFailure(id: String, errorMessage: String) {
        val existing = database.transferDao().getTransferById(id)
        if (existing != null) {
            database.transferDao().updateTransfer(
                existing.copy(
                    status = TransferStatus.FAILED,
                    errorMessage = errorMessage
                )
            )
        }
    }
}
