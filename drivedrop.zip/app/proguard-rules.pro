# Add project specific ProGuard rules here.
# By default, the flags in this file are appended to flags specified
# in /path/to/sdk/tools/proguard/proguard-android.txt

# Google API Client Proguard rules
-keepclassmembers class * {
  @com.google.api.client.util.Key <fields>;
}
-keepattributes Signature,RuntimeVisibleAnnotations,AnnotationDefault
-dontwarn sun.misc.Unsafe

# OkHttp Proguard rules
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn javax.annotation.**

# Room Proguard rules
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**
